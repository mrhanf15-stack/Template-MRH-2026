# Wireframe Website Status

## Aktueller Stand
- Hero-Sektion: Sieht gut aus mit Hintergrundbild, Titel, Buttons und Stats
- Desktop Wireframe: Browser-Frame mit Topbar, Free Shipping Bar, Header, Navigation, Mega-Menu, Sticky Header, Produktkarten
- Mobile Wireframe: Zwei Phone-Mockups (Shop-Ansicht + Offcanvas), Toggle-Switch, Feature-Callouts
- Tech Specs Tabelle: Alt vs. Neu Vergleich
- Footer: Links zu GitHub, Versionsinfo

## Zu beheben
- Section Labels: Die absolute Positionierung mit translateX(-100%) funktioniert nicht gut, die Labels werden abgeschnitten. Besser: Labels als kleine Badges direkt im Wireframe-Inhalt positionieren.
- Mega-Menu Spaltenüberschriften werden durch die Annotation-Nummern überlagert

## Asset URLs
- Hero BG: https://d2xsxph8kpxj0f.cloudfront.net/310419663030623217/kxeGuRBrUVHSq5Rr7r3MZW/hero-wireframe-bg-j7cBxzZkJgkouWTV7U9iMJ.webp
- Product 1: https://d2xsxph8kpxj0f.cloudfront.net/310419663030623217/kxeGuRBrUVHSq5Rr7r3MZW/cannabis-product-card-1-Wo5ZovBFXz9tMpFuoznUyf.webp
- Product 2: https://d2xsxph8kpxj0f.cloudfront.net/310419663030623217/kxeGuRBrUVHSq5Rr7r3MZW/cannabis-product-card-2-7zRDptscx986LK3onLggtE.webp
