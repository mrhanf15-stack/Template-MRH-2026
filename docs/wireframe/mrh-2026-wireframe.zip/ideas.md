# MRH 2026 Wireframe – Design-Ideen

## Kontext
Dies ist ein interaktiver Wireframe-Prototyp für das MRH 2026 Template-Projekt (mr-hanf.de). Die Website dient als Design-Referenz und zeigt Navigation (Desktop + Mobile), Produktkarten, Sticky Header, Mega-Menu, Offcanvas-Navigation und Bottom Bar.

---

<response>
## Idee 1: "Technical Blueprint"
<probability>0.07</probability>

**Design Movement:** Industrial Blueprint / Technical Drawing Aesthetic
**Core Principles:** Präzision, Annotationen, technische Klarheit, Wireframe-Charakter bewahren
**Color Philosophy:** Dunkler Hintergrund (#0f172a Slate-900) mit leuchtend grünen Annotationslinien (#4ade80) und weißen Wireframe-Elementen. Der Kontrast zwischen dem dunklen "Zeichenbrett" und den hellen Wireframes erzeugt den Eindruck eines technischen Blueprints.
**Layout Paradigm:** Annotiertes Grid-System mit gestrichelten Begrenzungslinien, nummerierten Sektionen und Callout-Pfeilen die auf Elemente zeigen.
**Signature Elements:** 1) Gestrichelte Begrenzungsrahmen um jede Sektion 2) Nummerierte Callout-Badges mit Verbindungslinien 3) Monospace-Beschriftungen
**Interaction Philosophy:** Hover über Sektionen zeigt detaillierte Spezifikationen. Klick auf Annotationen öffnet Erklärungen.
**Animation:** Subtile "Drawing"-Animation beim Laden – Linien werden gezeichnet, dann füllen sich die Elemente.
**Typography System:** JetBrains Mono für Labels/Annotationen, Inter für UI-Elemente im Wireframe selbst.
</response>

<response>
## Idee 2: "Clean Showcase"
<probability>0.06</probability>

**Design Movement:** Swiss Design / Minimalistischer Showcase
**Core Principles:** Klarheit, Weißraum, typografische Hierarchie, Device-Mockups als Helden
**Color Philosophy:** Fast reines Weiß (#fafafa) als Hintergrund, MRH-Grün (#4a8c2a) als Akzent, Charcoal (#1a1a2e) für Text. Minimal und professionell – die Wireframes selbst sind die Stars.
**Layout Paradigm:** Vertikaler Scroll mit großzügigen Sektionen. Jede Sektion zeigt einen Aspekt (Header, Nav, Cards, Mobile) in einem realistischen Device-Mockup (Browser-Frame, iPhone-Frame).
**Signature Elements:** 1) Realistische Browser/Device-Mockups 2) Große Sektions-Überschriften mit grüner Unterstreichung 3) Vergleichstabellen Alt vs. Neu
**Interaction Philosophy:** Smooth Scroll zwischen Sektionen. Sticky Table of Contents links. Hover auf Mockups zeigt Zoom.
**Animation:** Fade-in beim Scrollen, sanfte Parallax-Effekte auf Mockups.
**Typography System:** Outfit (Display/Headlines), DM Sans (Body), JetBrains Mono (Code/Specs).
</response>

<response>
## Idee 3: "Interactive Playground"
<probability>0.08</probability>

**Design Movement:** Notion-artiger interaktiver Dokumentationsstil
**Core Principles:** Interaktivität, Toggle zwischen Ansichten, Live-Vergleich, Hands-on-Erlebnis
**Color Philosophy:** Warmes Off-White (#f8f6f3) mit sanftem Grün (#4a8c2a) und einem warmen Grau (#374151). Einladend und nicht steril.
**Layout Paradigm:** Sidebar-Navigation links (fixiert) mit scrollbarem Content rechts. Jede Sektion ist ein "Block" der expandiert/kollabiert werden kann.
**Signature Elements:** 1) Toggle-Switches "Desktop ↔ Mobile" für Live-Umschaltung 2) Expandierbare Sektionen mit Chevrons 3) Inline-Code-Snippets für technische Specs
**Interaction Philosophy:** Alles ist klickbar und interaktiv. User kann zwischen Desktop/Mobile umschalten, Sektionen auf/zuklappen, und Details ein/ausblenden.
**Animation:** Spring-basierte Animationen (Framer Motion), sanftes Accordion-Öffnen, Smooth Resize bei Desktop↔Mobile Toggle.
**Typography System:** Plus Jakarta Sans (Headlines), Inter (Body), Fira Code (technische Specs).
</response>

---

## Gewählter Ansatz: Idee 2 – "Clean Showcase"

**Begründung:** Der "Clean Showcase"-Ansatz ist ideal für einen Wireframe-Prototypen, der als professionelle Design-Referenz dient. Die realistischen Device-Mockups (Browser-Frame für Desktop, iPhone-Frame für Mobile) geben dem Team sofort ein Gefühl dafür, wie das fertige Template aussehen wird. Der Swiss-Design-Ansatz mit viel Weißraum lenkt nicht vom eigentlichen Wireframe-Inhalt ab, sondern hebt ihn hervor. Die Vergleichstabellen "Alt vs. Neu" sind besonders wertvoll für die Dokumentation der Design-Entscheidungen.
