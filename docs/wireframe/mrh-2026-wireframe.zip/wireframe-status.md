# Wireframe Status - 28.03.2026

## Aktualisierungen in dieser Iteration

1. **Logo:** MRH-Logo (logo_head.png) statt grünem Platzhalter - im Hero, Desktop-Header, Sticky-Header und Mobile-Header
2. **KK-Mega-Menu:** Labels aktualisiert auf "KK-Mega-Menu kompatibel (3-Spalten, Banner-Platz)" und "KK-Mega-Menu Dropdown (main-3 Layout + Aktions-Banner rechts)"
3. **Banner-Position:** Label zeigt "MRH_BANNER_POSITION via config.php"
4. **TechSpecs:** 5 neue Zeilen: CSS (komplett neu), Komprimierung, Mega-Menu, AI Search, Konfiguration. Shop-Version zeigt "modified 3.0 ready"
5. **Alle MRH-Platzhalter** (grüne Boxen mit "MRH" Text) durch echtes Logo ersetzt

## Banner-Manager Integration (neu)
6. **Slider/Carousel** ({$SLIDER}) - Hero-Banner mit Carousel-Controls, Indicators und "Banner-Manager Admin" Badge
7. **Standard-Banner** ({$BANNER}) - Optionale Position nach Slider, vor Content
8. **Marketing Reihe 1** ({$MAREKTINGQ} col-md-3 + {$MAREKTINGQA} col-md-9)
9. **Marketing Reihe 2** ({$MAREKTINGQB} col-md-9 + {$MAREKTINGQC} col-md-3)

## Verifiziert im Browser
- Hero: Logo rechts neben Text ✓
- Desktop Header: Echtes Logo ✓
- Sticky Header: Echtes Logo (kleiner) ✓
- Mobile Header: Echtes Logo ✓
- KK-Mega-Menu Labels korrekt ✓
- Banner-Manager Slider mit Controls/Indicators ✓
- Standard-Banner Position ({$BANNER}) mit "Optional" Badge ✓
- Marketing-Banner Reihe 1 (Q + QA) korrekt ✓
- Marketing-Banner Reihe 2 (QB + QC) korrekt ✓
- Newsletter RevPlus-Stil ✓
- Footer 4-Spalten ✓
- TechSpecs Tabelle erweitert ✓

## Shop-Module Integration (neu)
10. **Neue Artikel** ({$box_WHATSNEW}) - Shop-gesteuert, config: MRH_STARTPAGE_BOX_WHATSNEW ✓
11. **Sonderangebote** ({$box_SPECIALS}) - Shop-gesteuert, config: MRH_STARTPAGE_BOX_SPECIALS ✓
12. **Zuletzt angesehen** ({$box_LAST_VIEWED}) - Shop-gesteuert, config: MRH_STARTPAGE_BOX_LAST_VIEWED ✓
13. **Bestseller Carousel** ({$box_BESTSELLERS}) - Shop-gesteuert, config: MRH_BSCAROUSEL_SHOW ✓
14. Alle mit "Shop-Modul" Badge und Smarty-Variablen-Referenz ✓

## Komplette Startseiten-Reihenfolge
01 Topbar → 02 Free Shipping → 03 Header → 04 Navigation → 04a Mega-Menu → 05 Sticky Header → 06 Slider → 06a Banner → 07 Neue Artikel → 08 Sonderangebote → 08a Zuletzt angesehen → 09 Marketing Reihe 1 → 10 Bestseller → 10a Marketing Reihe 2 → 11 Newsletter → 12 Footer
