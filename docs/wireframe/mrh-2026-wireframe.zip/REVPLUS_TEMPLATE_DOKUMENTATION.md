# RevPlus Template – Vollständige technische Dokumentation

**Basis-Template:** RevPlus modified 3.1.5-1.0.2
**Ziel-Template:** tpl_mrh_2026
**Dokumentiert am:** 2026-03-30
**Zweck:** Referenzdokumentation für den Umbau von RevPlus zu MRH 2026

---

## 1. Übersicht und Architektur

Das RevPlus Template ist ein professionelles, responsives Template für die modified eCommerce Shopsoftware v3.x. Es basiert auf **Bootstrap 5.2.3**, nutzt **jQuery 3.6.0** für Interaktionen, **Font Awesome 6.4.2** für Icons und die **Smarty 4** Template Engine. Das Template bietet einen integrierten JSON-basierten Design-Konfigurator, der Farben, Logos, Social-Media-Links und Template-Einstellungen über eine Admin-Oberfläche steuerbar macht.

Die Gesamtstruktur umfasst **1.206 Dateien**, aufgeteilt in 208 HTML-Templates, 69 PHP-Dateien, 83 CSS-Dateien, 64 JavaScript-Dateien, 8 JSON-Konfigurationsdateien, 604 Bilddateien und 43 Font-Dateien.

---

## 2. Verzeichnisstruktur

| Verzeichnis | Inhalt | Dateien | Beschreibung |
|---|---|---|---|
| `/` (Root) | index.html, offline.html, stylesheet.css/.min.css | 4 | Haupt-Templates und komprimiertes CSS |
| `/admin/` | print_order.html, print_packingslip.html | 2 | Admin-Druckvorlagen |
| `/ajax/` | cart-modalwindow.html, cart-modalwindow--mobile.html | 2 | AJAX-Warenkorb-Modals |
| `/assets/bootstrap/` | CSS + JS | 24 | Bootstrap 5.2.3 vollstaendig mit Maps |
| `/assets/fietz-accessibility-widget/` | JS + CSS + Fonts | 5 | BFSG-Barrierefreiheits-Widget |
| `/boxes/` | 33 HTML-Dateien | 33 | Smarty Box-Templates (Sidebar, Footer, etc.) |
| `/buttons/` | Unterordner je Sprache | 4 | Button-Grafiken (DE, EN, FR, NL) |
| `/config/` | PHP + JSON | 9 | Template-Konfiguration und Design-Tokens |
| `/css/` | CSS, CSS.PHP, Fonts, Images | ca. 40 | Stylesheets, Font-Dateien, CSS-Bilder |
| `/favicons/` | Icons + Manifest | 9 | Favicon-Set alle Plattformen |
| `/fonts/` | TTF, WOFF, WOFF2, EOT, SVG | ca. 15 | Simple Line Icons Font-Familie |
| `/img/` | PNG, JPG, WEBP, GIF, SVG | ca. 100 | Template-Bilder, Social Icons, Payment/Shipping |
| `/javascript/` | JS-Dateien + Unterordner | ca. 35 | jQuery, Bootstrap, Plugins, Owl Carousel |
| `/lang/` | Custom + Section Dateien | 16 | Sprachdateien (DE, EN, FR, NL) |
| `/mail/` | HTML + TXT je Sprache | 76 | E-Mail-Templates |
| `/module/` | HTML-Dateien + Unterordner | 87 | Seiten-Templates (Checkout, Account, Produkt) |
| `/parents/` | boxes/cart.tpl | 1 | Parent-Template Override Warenkorb |
| `/smarty/` | PHP + .htaccess | 3 | Smarty Plugin-Registrierung |
| `/source/` | PHP-Dateien | 48 | Box-Logik, Includes, Template-Konfigurator |
| `/tpl_parts/` | HTML-Dateien | 14 | Wiederverwendbare Template-Teile |
| `/unitegallery/` | JS, CSS, Images, Skins, Themes | ca. 80 | Produktbild-Galerie (Unite Gallery) |

---

## 3. Kern-Dateien und ihre Funktion

### 3.1 index.html – Haupt-Layout

Die index.html ist das zentrale Smarty-Template und steuert den gesamten Seitenaufbau. Sie unterscheidet zwischen **Startseite** (`{if isset($home) && $home == true}`) und **Unterseiten** (`{else}`).

**Startseiten-Aufbau (von oben nach unten):**

| Pos | Smarty-Variable / Include | Beschreibung |
|---|---|---|
| 01 | `{$box_ADMIN}` | Admin-Toolbar (nur fuer Admins) |
| 02 | `{$box_MISCELLANEOUS_CM}` | Content-Manager Miscellaneous Box |
| 03 | `{include "tpl_parts/content_head.html"}` | Header: Logo, Suche, Badges, Mobile-Toggle |
| 04 | `{include "tpl_parts/navigation.html"}` | Hauptnavigation (horizontal oder vertikal) |
| 05 | `{$SLIDER}` | Banner-Slider/Carousel (Bootstrap Carousel) |
| 06 | `{include "tpl_parts/banners.html"}` | Seitenbanner (nur bei horizontal-Menue) |
| 07 | Service-Boxen | 3 Spalten: Telefon, Newsletter, Lieferung |
| 08 | `{$box_SLIDER_NEW}` | Neue Produkte (Owl Carousel) |
| 09 | `{$main_content}` + `{$BANNERHOME}` | Hauptinhalt + Home-Banner |
| 10 | `{$box_SLIDER_TOP}` | Top-Produkte (mit Hintergrundbild) |
| 11 | `{$box_SLIDER_SPECIALS}` | Sonderangebote |
| 12 | `{$box_SLIDER_BESTSELLERS}` | Bestseller |
| 13 | `{include "tpl_parts/banners2.html"}` | Marketing-Banner (4 Positionen) |
| 14 | `{$box_SLIDER_RANDOM}` | Zufaellige Produkte |
| 15 | `{$box_NEWSLETTER}` | Newsletter-Box |
| 16 | `{include "tpl_parts/footer.html"}` | Footer |

**Unterseiten-Aufbau:** Breadcrumb-Navigation, optionale Sidebar (bei vertikalem Menue mit Kategorien, Zuletzt angesehen, Sonderangebote, Neue Artikel) und Hauptinhalt.

**Offcanvas-Elemente (nach Footer):**

| Element | ID | Beschreibung |
|---|---|---|
| Mobile Navigation | navigation_mobile.html | Mobile Navigationsleiste |
| Offcanvas Menue | menu_offcanvas.html | Ausklappbares Seitenmenue |
| Warenkorb Offcanvas | #offcanvasCart | Warenkorb-Seitenleiste |
| Einstellungen Offcanvas | #offcanvasSettings | Sprache, Waehrung, Lieferland |
| Mobiles Menue | #mobiles_menu | Kategorie-Navigation mobil |
| Popup Modal | #popupContent | iFrame-basiertes Popup |
| Cookie Consent | Cookie-Button + SVG | DSGVO Cookie-Hinweis |
| Infinite Scroll | infinite_scroll.html | Endloses Scrollen (optional) |
| Barrierefreiheit | Fietz Widget | BFSG-Accessibility-Tool (optional) |
| Template Config | `{$box_templateconfig}` | Design-Konfigurator (nur Admin) |

### 3.2 config/config.php – Template-Konfiguration

Diese Datei wird beim Laden des Templates automatisch eingebunden und definiert zentrale Konstanten.

| Konstante | Wert | Beschreibung |
|---|---|---|
| `DIR_FS_BOXES` | templates/CURRENT_TEMPLATE/source/boxes/ | Pfad zu Box-PHP-Dateien |
| `DIR_FS_BOXES_INC` | templates/CURRENT_TEMPLATE/source/inc/ | Pfad zu Include-Dateien |
| `TEMPLATE_ENGINE` | smarty_4 | Smarty-Version (nicht aendern!) |
| `TEMPLATE_HTML_ENGINE` | html5 | HTML-Ausgabeformat |
| `TEMPLATE_RESPONSIVE` | true | Responsive Design aktiv |
| `COMPRESS_JAVASCRIPT` | true | JS-Dateien kombinieren/komprimieren |
| `PRODUCT_LIST_BOX` | Session-basiert / true | Box- vs. Listenansicht |
| `PRODUCT_LIST_BOX_STARTPAGE` | true | Startseite: Box-Ansicht |
| `PRODUCT_INFO_BOX` | true | Produktdetail: Box-Ansicht |
| `SPECIALS_CATEGORIES` | true | Angebote im Kategoriebaum |
| `WHATSNEW_CATEGORIES` | true | Neue Artikel im Kategoriebaum |
| `MAX_PRODUCTS_BOX` | 10 | Max. Produkte pro Box |
| `TPLCFG_BOXED` | false | Kein Boxed-Layout |

### 3.3 source/boxes.php – Box-Orchestrierung

Diese Datei steuert, welche Boxen wann geladen werden. Sie definiert zunaechst eine Allowlist fuer Full-Content-Seiten (Checkout, Account, etc.) und laedt dann kontextabhaengig die Box-Provider.

**Immer sichtbare Boxen:** gettplconfigs, search, categories, content, manufacturers, last_viewed, information, miscellaneous, miscellaneous2, miscellaneous_cm, footer_text, best_sellers, shopinfo, languages, infobox, login

**Bedingt geladene Boxen:**

| Bedingung | Boxen |
|---|---|
| Newsletter aktiv | newsletter |
| Trusted Shops aktiv | trustedshops |
| Preise sichtbar | add_a_quickie, cart, wishlist |
| Admin eingeloggt | admin, templateconfig |
| Produktdetailseite | manufacturer_info |
| Kunde eingeloggt | order_history |
| Bewertungen erlaubt | reviews |
| Nicht im Checkout | currencies, shipping_country |
| Nur Startseite | slider_top, slider_new, slider_random, slider_bestsellers, slider_specials |

---

## 4. JSON-basierter Design-Konfigurator

Das RevPlus Template verfuegt ueber ein einzigartiges Konfigurationssystem, das Design-Einstellungen in JSON-Dateien speichert und ueber eine Admin-Oberflaeche editierbar macht. Die Logik befindet sich in `source/boxes/templateconfig.php`, die Oberflaeche in `boxes/box_templateconfig.html`.

### 4.1 Konfigurationsdateien

| Datei | Zweck | Felder |
|---|---|---|
| config/colors.json | Farbschema | 14 CSS-Custom-Properties |
| config/tplsettings.json | Template-Optionen | SSL, TS, Menue, Scroll, Barrierefreiheit |
| config/logos.json | Payment/Shipping Logos | Arrays mit aktiven Logos |
| config/social.json | Social-Media-Links | Facebook, X, Instagram, Pinterest, LinkedIn |
| config/default_*.json | Fallback-Defaults | Identische Struktur fuer Reset |

### 4.2 CSS Custom Properties (Farb-Tokens)

Die Farben werden aus colors.json gelesen und als CSS Custom Properties in den Head injiziert (via css/general.css.php). Zusaetzlich existiert eine statische Fallback-Datei css/variables.css.

| CSS Variable | Standard-Wert | Verwendung |
|---|---|---|
| --tpl-main-color | #7a64ff | Primaerfarbe (Buttons, Links, Akzente) |
| --tpl-main-color-2 | #4fb898 | Sekundaerfarbe |
| --tpl-bg-color | #fcfcfc | Seitenhintergrund |
| --tpl-bg-color-2 | #f5f5f5 | Alternativer Hintergrund |
| --tpl-bg-productbox | #ffffff | Produktbox-Hintergrund |
| --tpl-bg-footer | #e0e3e5 | Footer-Hintergrund |
| --tpl-text-standard | #444 | Standard-Textfarbe |
| --tpl-text-headings | #333 | Ueberschriften |
| --tpl-text-button | #ffffff | Button-Text |
| --tpl-text-footer | #8c8c8c | Footer-Text |
| --tpl-text-footer-headings | #696969 | Footer-Ueberschriften |
| --tpl-borders-color | #dbdbdb | Rahmenfarbe |
| --tpl-font-heading | MS Sans Serif | Ueberschriften-Font |
| --tpl-font-text | MS Sans Serif | Text-Font |

---

## 5. CSS-Architektur

### 5.1 CSS-Ladereihenfolge (Head via general.css.php)

| Nr | Datei | Beschreibung |
|---|---|---|
| 1 | adminbar.css | Nur fuer Admins |
| 2 | jquery.mmenu.all.css | Mobile Menue (mmenu) |
| 3 | bootstrap.min.css | Bootstrap 5.2.3 (aus css/) |
| 4 | cssbuttons.css | Template-spezifische Buttons |
| 5 | simple-line-icons.css | Simple Line Icons |
| 6 | template.css | Haupt-Template-Stylesheet |
| 7 | variables.css | CSS Custom Properties (Fallback) |
| 8 | Inline Style | JSON-basierte Farb-Overrides aus colors.json |
| 9 | unite-gallery.css | Nur auf Produktdetailseiten |
| 10 | shariff.complete.css | Nur auf Produktdetailseiten (Social Share) |

### 5.2 CSS-Ladereihenfolge (Bottom via general_bottom.css.php)

| Nr | Datei | Beschreibung |
|---|---|---|
| 1 | owl.carousel.css | Owl Carousel Slider |
| 2 | cookieconsent.css | Cookie-Consent-Banner |
| 3 | fontawesome-6.css | Font Awesome 6.4.2 |

Bei Komprimierung werden diese in tpl_plugins.min.css zusammengefasst.

---

## 6. JavaScript-Architektur

Das Template nutzt jQuery 3.6.0 als Basis und laedt zahlreiche jQuery-Plugins. Bei aktivierter Komprimierung werden die Dateien in combined_head.js bzw. tpl_plugins.min.js zusammengefasst.

### 6.1 JavaScript-Bibliotheken und Upgrade-Plan

| Datei | Version | Beschreibung | MRH 2026 Aktion |
|---|---|---|---|
| jquery.min.js | 3.6.0 | jQuery Core | ENTFERNEN -> Vanilla JS |
| jquery-1.8.3.min.js | 1.8.3 | Legacy jQuery | ENTFERNEN |
| jquery-migrate-1.4.1.min.js | 1.4.1 | jQuery Migration | ENTFERNEN |
| bootstrap.bundle.min.js | 5.2.3 | Bootstrap JS + Popper | UPGRADE -> 5.3 |
| popper.min.js | -- | Popper.js separat | In BS5.3 Bundle enthalten |
| owl.carousel.min.js | -- | Produkt-Slider | ERSETZEN -> Vanilla/Swiper |
| jquery.mmenu.all.js | -- | Mobile Menue | ERSETZEN -> BS5 Offcanvas |
| jquery.colorbox.min.js | -- | Lightbox/Modal | ERSETZEN -> BS5 Modal |
| jquery.bxslider.min.js | -- | Slider | ERSETZEN |
| jquery.alertable.min.js | -- | Alert-Dialoge | ERSETZEN -> BS5 Toast |
| jquery.alerts.min.js | -- | Alert-Dialoge alt | ERSETZEN |
| jquery.easyTabs.min.js | -- | Tab-Navigation | ERSETZEN -> BS5 Tabs |
| jquery.menu-aim.js | -- | Mega-Menue Hover | ERSETZEN -> Vanilla |
| jquery.css3-multi-column.js | -- | CSS3 Multi-Column | ENTFERNEN (nativ) |
| jquery.slicknav.min.js | -- | Mobile Nav | ERSETZEN |
| jquery.unveil.min.js | -- | Lazy Loading | ENTFERNEN (nativ loading=lazy) |
| slideout.min.js | -- | Slide-Out Menue | ERSETZEN -> BS5 Offcanvas |
| bootstrap-select.js | -- | Select-Dropdown | ERSETZEN -> Vanilla |
| cookieconsent.min.js | -- | Cookie-Consent | Beibehalten/Aktualisieren |
| infiniteajaxscroll-com.js | -- | Infinite Scroll | Optional beibehalten |
| shariff.min.js | -- | Social Share datenschutzkonform | Beibehalten |
| currency-accessibility.js | -- | WCAG Waehrungsauswahl | Beibehalten/Anpassen |
| javascript.js | -- | Template-spezifisches JS | NEUSCHREIBEN -> Vanilla |

---

## 7. Template-Parts (tpl_parts/)

| Datei | Groesse | Beschreibung |
|---|---|---|
| content_head.html | 31 KB | Haupt-Header: Logo, Suche, Badges (TS, SSL), Mobile-Toggle, Schema.org |
| footer.html | 1.8 KB | Footer: 4 Spalten, Footer-Text, Shopinfo, Fietz-Credit |
| navigation.html | 1.2 KB | Desktop-Navigation: Smarty box_CATEGORIES mit Home-Link |
| navigation_mobile.html | 4.3 KB | Mobile Navigation (aktuell auskommentiert!) |
| social_icons.html | 3.1 KB | Social Icons: Footer + Sticky-Sidebar |
| banners.html | 769 B | Seitenbanner: 2 Positionen (BANNER1, BANNER2) |
| banners2.html | 1.5 KB | Marketing-Banner: 4 Positionen (BANNER3-6) |
| content_home.html | 203 B | Home-Content Wrapper |
| content_home_2.html | 0 B | Leer (Platzhalter) |
| side_content.html | 204 B | Sidebar-Content |
| map.html | 688 B | Google Maps Einbindung |
| infinite_scroll.html | 213 B | Infinite Scroll Script |
| menu_offcanvas.html | 295 B | Auskommentiert: Offcanvas mit Sprache/Waehrung |

---

## 8. Box-Templates (boxes/) – 33 Dateien

### 8.1 Wichtigste Boxen

| Box-Template | PHP-Logik | Smarty-Variable | Beschreibung |
|---|---|---|---|
| box_admin.html | admin.php | {$box_ADMIN} | Admin-Toolbar |
| box_cart.html | cart.php | {$box_CART} | Warenkorb |
| box_categories.html | categories.php | {$box_CATEGORIES} | Kategoriebaum |
| box_content.html | content.php | {$box_CONTENT} | Content-Manager Links |
| box_information.html | information.php | {$box_INFORMATION} | Informationsseiten |
| box_login.html | login.php | {$box_LOGIN} | Login-Box |
| box_manufacturers.html | manufacturers.php | {$box_MANUFACTURERS} | Hersteller-Dropdown |
| box_newsletter.html | newsletter.php | {$box_NEWSLETTER} | Newsletter-Anmeldung |
| box_search.html | search.php | {$box_SEARCH} | Suchfeld |
| box_wishlist.html | wishlist.php | {$box_WISHLIST} | Merkzettel |

### 8.2 Slider-Boxen (nur Startseite)

| Box-Template | Smarty-Variable | Beschreibung |
|---|---|---|
| box_slider_new.html | {$box_SLIDER_NEW} | Neue Produkte Carousel |
| box_slider_top.html | {$box_SLIDER_TOP} | Top-Produkte Carousel |
| box_slider_specials.html | {$box_SLIDER_SPECIALS} | Sonderangebote Carousel |
| box_slider_bestsellers.html | {$box_SLIDER_BESTSELLERS} | Bestseller Carousel |
| box_slider_random.html | {$box_SLIDER_RANDOM} | Zufaellige Produkte Carousel |

Alle Slider nutzen Owl Carousel (jQuery-Plugin) und muessen fuer MRH 2026 durch Vanilla JS ersetzt werden.

### 8.3 Weitere Boxen

box_add_a_quickie, box_bestsellers, box_currencies, box_footer_text, box_languages, box_last_viewed, box_loginbox, box_manufacturers_info, box_miscellaneous, box_miscellaneous2, box_miscellaneous_cm, box_newsrss, box_order_history, box_reviews, box_shipping_country, box_shopinfo, box_specials, box_templateconfig (23 KB Design-Konfigurator UI), box_trustedshops, box_whatsnew

---

## 9. Module (module/) – 87 Dateien

### 9.1 Checkout (9 Dateien)

checkout_confirmation, checkout_new_address, checkout_payment, checkout_payment_address, checkout_payment_block, checkout_shipping, checkout_shipping_address, checkout_shipping_block, checkout_success

### 9.2 Account (15 Dateien)

account, account_checkout_express, account_delete, account_edit, account_history, account_history_info, account_password, address_book, address_book_details, address_book_process, create_account, create_account_guest, login, logoff, password_double_opt_in

### 9.3 Produkt (14 Dateien)

product_info/product_info_v1, product_listing/product_listing_v1, product_navigator, product_options/ (4 Varianten), product_reviews, product_reviews_info, product_reviews_write, product_tags, products_category, products_media, products_reviews

### 9.4 Kategorie (3 Dateien)

categorie_listing/categorie_listing, sub_categories_listing, sub_content_listing

### 9.5 Includes (10 Dateien)

price_box, price_info, price_listing, product_box, product_info_include, product_listing_include, product_row, products_include_box, products_include_info, products_include_listing

### 9.6 Sonstige (36 Dateien)

advanced_search, also_purchased, autocomplete, breadcrumb, contact_us, content, cookie_usage, cross_selling, downloads, error_message, gift_cart, graduated_price, gv_redeem, gv_send, listing_filter, main_content, message_stack, new_products, new_products_default, newsletter, order_details, pagination, popup_content, popup_coupon_help, popup_search_help, print_order, print_product_info, reverse_cross_selling, reviews, shopping_cart, sitemap, ssl_check, upcoming_products, wishlist, offline/login_shop, ajax/modal-cart-content

---

## 10. Sprachdateien (lang/)

4 Sprachen: Deutsch, Englisch, Franzoesisch, Niederlaendisch. Pro Sprache zwei Dateien: lang_XX.custom (Smarty Config-Variablen fuer alle Template-Texte) und lang_XX.section (Abschnitts-basierte Variablen). Die .custom-Datei enthaelt alle UI-Texte: Header, Footer, Newsletter, Service-Boxen, Buttons, WCAG-Labels, Cookie-Texte, Social-Media-Labels.

---

## 11. E-Mail-Templates (mail/)

Pro Sprache existieren 11 E-Mail-Templates (jeweils HTML + TXT): contact_us, create_account_mail, downloads, new_password_mail, newsletter_mail, order_mail, order_mail_step, send_gift_to_friend, sepa_info (nur HTML), sepa_mail, signatur

---

## 12. Aktuelle Fehler auf mr-hanf.at (Error-Log 2026-03-30)

### 12.1 Kritisch: Fehlende box_categories2.html

Bei jedem einzelnen Request tritt der Fehler `Unable to load template 'file:tpl_mrh_2026/boxes/box_categories2.html'` auf. Das alte Template referenziert eine box_categories2.html, die nicht existiert. RevPlus verwendet stattdessen box_categories.html. Beim Umbau muss entweder die Datei angelegt oder die Referenz in der aufrufenden PHP-Datei korrigiert werden.

### 12.2 Fehlende Webfonts (404)

Das alte Template versucht Webfonts aus einem /webfonts/-Verzeichnis zu laden: OpenSans (Regular, Italic, Bold), produkt_info.woff2, Font Awesome Fonts (fa-regular-400, fa-brands-400, fa-solid-900). RevPlus speichert Fonts unter css/fonts/.

### 12.3 Fehlende CSS-Dateien (404)

Referenzierte aber nicht vorhandene CSS: bs4.css, bootstrap/bootstrap.min.css, pushy.min.css, all.min.css, navbar.css, shop_reviews.css, blog.css, manufacturers_overview.css, customers_notice.css. Alle werden durch die RevPlus-CSS-Architektur ersetzt.

### 12.4 Fazit

Alle Fehler werden durch den Austausch des alten tpl_mrh_2026 mit dem RevPlus-basierten Template behoben. Der einzige Sonderfall ist box_categories2.html, wo geprueft werden muss ob eine externe PHP-Datei diese Box aufruft.

---

## 13. Upgrade-Plan: RevPlus zu MRH 2026

### Phase 1 – Foundation (Sofort)

RevPlus-Dateien als tpl_mrh_2026 auf Server kopieren, Template in Datenbank aktivieren, box_categories2.html Problem loesen, OPcache zuruecksetzen, Frontend-Test.

### Phase 2 – Design System

colors.json mit MRH Corporate Identity, logos.json mit MRH Payment/Shipping, social.json mit MRH Social-Media, tplsettings.json anpassen.

### Phase 3 – Technology Upgrade

| Komponente | Aktuell | Ziel | Aktion |
|---|---|---|---|
| Bootstrap | 5.2.3 | 5.3.x | CSS + JS austauschen |
| jQuery | 3.6.0 | entfernen | Komplett entfernen |
| Font Awesome | 6.4.2 | 6.7.x | CSS + Fonts austauschen |
| Owl Carousel | jQuery-Plugin | Vanilla/Swiper | Slider neuschreiben |
| mmenu | jQuery-Plugin | BS5 Offcanvas | Mobile Menue neuschreiben |
| Colorbox | jQuery-Plugin | BS5 Modal | Lightbox neuschreiben |
| Simple Line Icons | Icon-Font | Font Awesome 6.7 | Icons ersetzen |

### Phase 4 – Template-Anpassung

Alle 87 Module, 33 Boxen und 14 Template-Parts auf BS5.3, Vanilla JS, FA6.7 und MRH 2026 Design anpassen.

---

## 14. Wichtige Hinweise

**OPcache:** Nach jeder PHP-Aenderung: `curl -s "https://mr-hanf.at/opcache_reset.php?token=MrHanf2024Reset"`

**Keine Core-Dateien aendern:** Nur Template-Dateien modifizieren. includes/, admin/ und andere Shop-Verzeichnisse bleiben unberuehrt.

**configure.php bewahren:** Enthaelt DB-Zugangsdaten und Pfade, niemals ueberschreiben.

**Smarty-Variablen:** Alle {$box_*} Variablen werden vom Shop-System bereitgestellt. Variablennamen sind fest.

**Komprimierung:** Bei Entwicklung deaktivieren (COMPRESS_JAVASCRIPT = false, COMPRESS_STYLESHEET = false).
