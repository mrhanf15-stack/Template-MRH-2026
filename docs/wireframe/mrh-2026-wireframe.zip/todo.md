# MRH 2026 Template – Todo

## Erledigte Aufgaben

- [x] Bootstrap4-Template autoinclude-Struktur analysieren
- [x] Banner-Platzierung und Konfiguration aus BS4-Template uebernehmen
- [x] Mega-Menu klären: KK-Mega mit 3 Spalten (main-3)
- [x] Modified 3.0 Kompatibilitaet recherchiert
- [x] Hero-Sektion durch modified Banner-Manager ersetzen
- [x] Logo statt gruenem MRH-Hintergrund
- [x] config.php mit MRH_-Prefix erstellt
- [x] index.html (Smarty) erstellt
- [x] stylesheet.css (CSS Layers) erstellt
- [x] mrh2026.js (Vanilla ES2024+) erstellt
- [x] 30 Boxen-Templates erstellt
- [x] 11 Module-Includes erstellt
- [x] 4 Smarty-Plugins erstellt
- [x] Sprachdateien DE/EN erstellt

## Aktuelle Aufgaben

### Phase 1: Aus BS4 uebernehmen (1:1)
- [ ] admin/ komplett kopieren
- [ ] mail/ komplett kopieren
- [ ] img/ komplett kopieren
- [ ] favicons/ komplett kopieren
- [ ] webfonts/ kopieren (nur noetige: FA, Custom Icons)
- [ ] buttons/ komplett kopieren
- [ ] source/boxes/ PHP-Dateien kopieren
- [ ] source/inc/ PHP-Dateien kopieren und pruefen
- [ ] source/external/ kopieren

### Phase 2: Frontend-Module neu in BS5.3 (47 Dateien)
- [ ] breadcrumb.html
- [ ] main_content.html (default.html)
- [ ] error_message.html
- [ ] pagination.html
- [ ] content.html
- [ ] cookie_usage.html
- [ ] login.html
- [ ] logoff.html
- [ ] create_account.html + create_account_guest.html
- [ ] account.html + account_edit.html + account_password.html
- [ ] account_history.html + account_history_info.html
- [ ] address_book.html + address_book_details.html + address_book_process.html
- [ ] shopping_cart.html
- [ ] checkout_shipping.html + checkout_payment.html + checkout_confirmation.html + checkout_success.html
- [ ] contact_us.html
- [ ] advanced_search.html
- [ ] wishlist.html
- [ ] sitemap.html
- [ ] newsletter.html
- [ ] downloads.html
- [ ] gv_redeem.html + gv_send.html
- [ ] cross_selling.html + also_purchased.html + reverse_cross_selling.html
- [ ] graduated_price.html
- [ ] product_options_dropdown.html
- [ ] product_reviews.html + product_reviews_write.html
- [ ] product_inquiry.html
- [ ] product_navigator.html
- [ ] popup_content.html + popup_coupon_help.html + popup_reviews.html + popup_search_help.html
- [ ] seedfinder.html (Custom)
- [ ] reklamation_form.html (Custom)
- [ ] gift_cart.html (Custom)
- [ ] blog.html (Custom)

### Phase 3: CSS/JS konsolidieren
- [ ] Alle CSS-Regeln in stylesheet.css zusammenfuehren
- [ ] Alle JS-Module in mrh2026.js zusammenfuehren
- [ ] Gesamtoptimierung und Redundanzen entfernen

### Phase 4: GitHub Push
- [ ] Alles committen und pushen
