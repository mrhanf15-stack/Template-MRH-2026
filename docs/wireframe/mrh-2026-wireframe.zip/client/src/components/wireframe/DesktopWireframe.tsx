import { motion } from "framer-motion";
import {
  Phone, Truck, ShieldCheck, Mail, ChevronDown, Search,
  Globe, User, Heart, ShoppingCart, Leaf, Clock,
  Star, Package, Monitor
} from "lucide-react";
import { SectionLabel, ProductCard, PRODUCT_IMG_1, PRODUCT_IMG_2, MRH_LOGO } from "./shared";

export default function DesktopWireframe() {
  return (
    <section id="desktop-wireframe" className="container mx-auto px-4 mb-24">
      <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-slate-100 rounded-full px-4 py-1.5 mb-4">
            <Monitor size={14} className="text-slate-500" />
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider"
              style={{ fontFamily: "var(--font-mono)" }}>Desktop Ansicht</span>
          </div>
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900" style={{ fontFamily: "var(--font-display)" }}>
            Navigation &amp; Layout
          </h2>
          <p className="text-slate-500 mt-2 max-w-lg mx-auto">
            Kein Sidebar. Alle Boxen intelligent verteilt. Volle Breite fuer maximale Wirkung.
          </p>
        </div>

        {/* Browser Frame */}
        <div className="max-w-5xl mx-auto relative">
          <div className="bg-[#e8e8e8] rounded-t-xl px-4 py-3 flex items-center gap-3">
            <div className="flex gap-1.5">
              <span className="w-3 h-3 rounded-full bg-[#ff5f57]" />
              <span className="w-3 h-3 rounded-full bg-[#ffbd2e]" />
              <span className="w-3 h-3 rounded-full bg-[#28c840]" />
            </div>
            <div className="flex-1 bg-white rounded-md px-4 py-1.5 text-xs text-slate-500 text-center"
              style={{ fontFamily: "var(--font-mono)" }}>https://mr-hanf.de</div>
          </div>

          <div className="bg-white border-x border-b border-slate-200 rounded-b-xl overflow-hidden shadow-2xl shadow-slate-200/50">

            {/* 01 TOPBAR */}
            <SectionLabel number="01" title="Topbar - Trust-Elemente" />
            <div className="bg-slate-800 text-white text-[11px] px-4 py-2 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <span className="flex items-center gap-1"><Phone size={10} /> +43 512 312 411</span>
                <span className="hidden sm:flex items-center gap-1"><Truck size={10} /> Schnelle Lieferung</span>
                <span className="hidden md:flex items-center gap-1"><ShieldCheck size={10} /> Sichere Zahlung</span>
                <span className="hidden lg:flex items-center gap-1"><Mail size={10} /> Briefbestellung</span>
              </div>
              <span className="font-semibold text-green-300">Kostenfrei ab: AT 40EUR, DE 85EUR, EU 150EUR</span>
            </div>

            {/* 02 FREE SHIPPING BAR */}
            <SectionLabel number="02" title="Free Shipping Progress Bar" />
            <div className="bg-[#f0fdf4] px-4 py-2">
              <div className="flex items-center gap-3">
                <div className="flex-1 bg-[#d1fae5] rounded-full h-2 overflow-hidden">
                  <div className="bg-[#4a8c2a] h-full rounded-full" style={{ width: "35%" }} />
                </div>
                <span className="text-[11px] text-[#3a7020] font-semibold whitespace-nowrap flex items-center gap-1">
                  <Package size={12} /> Noch <strong>85,00 EUR</strong> bis zum kostenlosen Versand!
                </span>
              </div>
            </div>

            {/* 03 HEADER */}
            <SectionLabel number="03" title="Header - Logo + Suche + Icons (Font Awesome)" />
            <div className="px-4 py-4 flex items-center gap-6 border-b border-slate-100">
              <div className="flex-shrink-0">
                <img src={MRH_LOGO} alt="Mr. Hanf" className="h-12 w-auto object-contain" />
              </div>
              <div className="flex-1 max-w-xl">
                <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg overflow-hidden">
                  <input type="text" placeholder="Cannabis Samen suchen..." className="flex-1 px-4 py-2.5 text-sm bg-transparent outline-none text-slate-600" readOnly />
                  <button className="bg-[#4a8c2a] text-white px-4 py-2.5"><Search size={16} /></button>
                </div>
              </div>
              <div className="flex items-center gap-5">
                {[
                  { icon: <Globe size={18} />, label: "Sprache" },
                  { icon: <User size={18} />, label: "Konto" },
                  { icon: <Heart size={18} />, label: "Merkliste" },
                ].map((item, i) => (
                  <button key={i} className="flex flex-col items-center gap-0.5 text-slate-500 hover:text-[#4a8c2a] transition-colors">
                    {item.icon}
                    <span className="text-[9px]">{item.label}</span>
                  </button>
                ))}
                <button className="flex flex-col items-center gap-0.5 text-slate-500 hover:text-[#4a8c2a] transition-colors relative">
                  <ShoppingCart size={18} />
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[8px] font-bold w-4 h-4 rounded-full flex items-center justify-center">2</span>
                  <span className="text-[9px]">Warenkorb</span>
                </button>
              </div>
            </div>

            {/* 04 MAIN NAVIGATION */}
            <SectionLabel number="04" title="Hauptnavigation - KK-Mega-Menu kompatibel (3-Spalten, Banner-Platz)" />
            <div className="bg-[#4a8c2a] px-4">
              <div className="flex items-center gap-0">
                {["Samen Shop", "Cannabispflanzen", "Growshop", "Headshop", "Angebote", "Neue Artikel", "Marken", "Blog", "Seedfinder"].map((item, i) => (
                  <button key={i} className={`text-white/90 hover:text-white hover:bg-white/10 text-xs font-medium px-3 py-3 transition-colors flex items-center gap-1 ${i === 0 ? "bg-white/15 text-white" : ""}`}>
                    {item}
                    {i < 4 && <ChevronDown size={10} />}
                  </button>
                ))}
              </div>
            </div>

            {/* 04a MEGA MENU */}
            <SectionLabel number="04a" title="KK-Mega-Menu Dropdown (main-3 Layout + Aktions-Banner rechts)" />
            <div className="bg-white border-b border-slate-200 px-6 py-5">
              <div className="grid grid-cols-4 gap-6">
                <div>
                  <h4 className="text-xs font-bold text-[#4a8c2a] uppercase tracking-wider mb-3 flex items-center gap-1">
                    <Leaf size={12} /> Sortenvielfalt
                  </h4>
                  {["THC-Reiche Sorten", "CBD-Reiche Sorten", "Autoflowering", "Feminisierte Samen", "Regulaere Samen"].map((s, i) => (
                    <a key={i} className="block text-sm text-slate-600 hover:text-[#4a8c2a] py-1 transition-colors cursor-pointer">{s}</a>
                  ))}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#4a8c2a] uppercase tracking-wider mb-3 flex items-center gap-1">
                    <Star size={12} /> Beliebte Sorten
                  </h4>
                  {["Amnesia Haze", "White Widow", "Northern Lights", "Girl Scout Cookies", "Gorilla Glue"].map((s, i) => (
                    <a key={i} className="block text-sm text-slate-600 hover:text-[#4a8c2a] py-1 transition-colors cursor-pointer">{s}</a>
                  ))}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#4a8c2a] uppercase tracking-wider mb-3 flex items-center gap-1">
                    <Package size={12} /> Top Hersteller
                  </h4>
                  {["Royal Queen Seeds", "Barney's Farm", "Dutch Passion", "Sensi Seeds", "Fast Buds"].map((s, i) => (
                    <a key={i} className="block text-sm text-slate-600 hover:text-[#4a8c2a] py-1 transition-colors cursor-pointer">{s}</a>
                  ))}
                </div>
                <div className="bg-[#f0fdf4] rounded-xl p-4 flex flex-col items-center justify-center text-center">
                  <span className="text-[10px] font-bold text-[#4a8c2a] uppercase tracking-wider mb-2">% Aktion</span>
                  <p className="text-sm font-semibold text-slate-800 mb-1">Royal Queen Seeds</p>
                  <p className="text-2xl font-extrabold text-[#4a8c2a] mb-3" style={{ fontFamily: "var(--font-display)" }}>2+1 GRATIS</p>
                  <button className="bg-[#4a8c2a] text-white text-xs font-semibold px-4 py-2 rounded-lg hover:bg-[#3a7020] transition-colors">Jetzt sparen</button>
                </div>
              </div>
            </div>

            {/* 05 STICKY HEADER */}
            <SectionLabel number="05" title="Sticky Header (erscheint beim Scrollen)" />
            <div className="bg-white border-b border-slate-200 px-4 py-2 flex items-center gap-4 shadow-sm">
              <div className="flex-shrink-0">
                <img src={MRH_LOGO} alt="Mr. Hanf" className="h-8 w-auto object-contain" />
              </div>
              <div className="flex items-center gap-0">
                {["Samen Shop", "Cannabispflanzen", "Growshop", "Headshop", "Angebote"].map((item, i) => (
                  <span key={i} className="text-slate-600 text-[11px] font-medium px-2 py-1 hover:text-[#4a8c2a] transition-colors cursor-pointer">{item}</span>
                ))}
              </div>
              <div className="flex-1 max-w-xs ml-auto">
                <div className="flex items-center bg-slate-50 border border-slate-200 rounded-md overflow-hidden">
                  <input type="text" placeholder="Suchen..." className="flex-1 px-3 py-1.5 text-[11px] bg-transparent outline-none" readOnly />
                  <button className="bg-[#4a8c2a] text-white px-2.5 py-1.5"><Search size={12} /></button>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <User size={16} className="text-slate-500" />
                <Heart size={16} className="text-slate-500" />
                <div className="relative">
                  <ShoppingCart size={16} className="text-slate-500" />
                  <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[7px] font-bold w-3.5 h-3.5 rounded-full flex items-center justify-center">2</span>
                </div>
              </div>
            </div>

            {/* 06 SLIDER / HERO CAROUSEL (Banner-Manager Gruppe "Slider") */}
            <SectionLabel number="06" title="Banner-Manager Slider/Carousel ({$SLIDER} - Gruppe 'Slider')" />
            <div className="bg-slate-100 relative overflow-hidden">
              <div className="flex items-center justify-center py-12 relative">
                {/* Carousel Mockup */}
                <div className="w-full max-w-full relative">
                  <div className="bg-gradient-to-r from-[#1a3a0a] to-[#2d5a1a] px-8 py-10 flex items-center justify-between">
                    <div>
                      <p className="text-green-300 text-xs font-semibold uppercase tracking-wider mb-2">Saisonstart 2026</p>
                      <h2 className="text-white text-2xl font-extrabold mb-2" style={{ fontFamily: "var(--font-display)" }}>Autoflowering Samen</h2>
                      <p className="text-green-200/80 text-sm mb-4">Die besten Sorten fuer Einsteiger und Profis</p>
                      <button className="bg-white text-[#1a3a0a] text-xs font-bold px-5 py-2.5 rounded-lg hover:bg-green-50 transition-colors">Jetzt entdecken</button>
                    </div>
                    <div className="w-40 h-32 bg-white/10 rounded-xl flex items-center justify-center">
                      <span className="text-white/40 text-xs">Banner Bild</span>
                    </div>
                  </div>
                  {/* Carousel Controls */}
                  <button className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-white">
                    <ChevronDown size={14} className="rotate-90" />
                  </button>
                  <button className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center text-white">
                    <ChevronDown size={14} className="-rotate-90" />
                  </button>
                  {/* Carousel Indicators */}
                  <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
                    <span className="w-6 h-1.5 bg-white rounded-full" />
                    <span className="w-6 h-1.5 bg-white/40 rounded-full" />
                    <span className="w-6 h-1.5 bg-white/40 rounded-full" />
                  </div>
                </div>
              </div>
              <div className="absolute top-2 right-2 bg-amber-100 text-amber-800 text-[9px] font-bold px-2 py-1 rounded">
                Banner-Manager Admin
              </div>
            </div>

            {/* 06a BANNER (Standard-Banner nach Slider) */}
            <SectionLabel number="06a" title="Standard-Banner ({$BANNER} - nach Slider, vor Content)" />
            <div className="bg-[#f0fdf4] border border-dashed border-[#4a8c2a]/30 px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-[#4a8c2a]/10 rounded-lg flex items-center justify-center">
                  <Package size={14} className="text-[#4a8c2a]" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-700">Banner-Manager Position: {'{$BANNER}'}</p>
                  <p className="text-[10px] text-slate-500">Wird im Admin unter Banner-Manager verwaltet</p>
                </div>
              </div>
              <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-2 py-1 rounded">Optional</span>
            </div>

            {/* 07 NEUE ARTIKEL - Shop-Box */}
            <SectionLabel number="07" title="Neue Artikel ({$box_WHATSNEW} - Shop-gesteuert, config: MRH_STARTPAGE_BOX_WHATSNEW)" />
            <div className="px-6 py-6 bg-[#f0fdf4]/50">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-slate-800" style={{ fontFamily: "var(--font-display)" }}>Neue Artikel</h3>
                <a className="text-[#4a8c2a] text-xs font-semibold hover:underline cursor-pointer">Alle anzeigen &raquo;</a>
              </div>
              <div className="grid grid-cols-4 gap-4">
                <ProductCard name="Purple Haze Auto" brand="Fast Buds" thc="19%" type="Sativa 80%" time="9-10 Wo." rating={0} reviews={0} price="12,50 EUR" badge={{ text: "Neu", color: "bg-blue-500" }} img={PRODUCT_IMG_1} />
                <ProductCard name="Zkittlez OG" brand="Barney's Farm" thc="23%" type="Indica 70%" time="8-9 Wo." rating={0} reviews={0} price="11,00 EUR" badge={{ text: "Neu", color: "bg-blue-500" }} img={PRODUCT_IMG_2} />
                <ProductCard name="Mimosa EVO" brand="Barney's Farm" thc="24%" type="Sativa 60%" time="9 Wo." rating={0} reviews={0} price="13,50 EUR" badge={{ text: "Neu", color: "bg-blue-500" }} img={PRODUCT_IMG_1} />
                <ProductCard name="Runtz Muffin" brand="Barney's Farm" thc="29%" type="Indica 60%" time="8-9 Wo." rating={0} reviews={0} price="14,00 EUR" badge={{ text: "Neu", color: "bg-blue-500" }} img={PRODUCT_IMG_2} />
              </div>
              <div className="mt-3 flex items-center gap-2">
                <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-2 py-1 rounded">Shop-Modul</span>
                <span className="text-[9px] text-slate-400">Daten vom modified-Core via Smarty, Darstellung via boxes/box_whatsnew.html</span>
              </div>
            </div>

            {/* 08 SONDERANGEBOTE - Shop-Box */}
            <SectionLabel number="08" title="Sonderangebote ({$box_SPECIALS} - Shop-gesteuert, config: MRH_STARTPAGE_BOX_SPECIALS)" />
            <div className="px-6 py-6 bg-[#fffbeb]">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-slate-800" style={{ fontFamily: "var(--font-display)" }}>Sonderangebote</h3>
                <a className="text-[#4a8c2a] text-xs font-semibold hover:underline cursor-pointer">Alle Angebote &raquo;</a>
              </div>
              <div className="grid grid-cols-4 gap-4">
                <ProductCard name="White Widow Auto" brand="Dutch Passion" thc="18%" type="Hybrid" time="8 Wo." rating={4} reviews={22} price="7,99 EUR" oldPrice="12,50 EUR" badge={{ text: "-36%", color: "bg-red-500" }} img={PRODUCT_IMG_2} />
                <ProductCard name="Northern Lights" brand="Sensi Seeds" thc="20%" type="Indica" time="7-8 Wo." rating={5} reviews={45} price="11,50 EUR" oldPrice="15,00 EUR" badge={{ text: "-23%", color: "bg-red-500" }} img={PRODUCT_IMG_1} />
                <ProductCard name="Gorilla Glue" brand="Fast Buds" thc="26%" type="Hybrid" time="9 Wo." rating={4.5} reviews={18} price="8,99 EUR" oldPrice="13,00 EUR" badge={{ text: "-31%", color: "bg-red-500" }} img={PRODUCT_IMG_2} />
                <ProductCard name="Girl Scout Cookies" brand="Fast Buds" thc="24%" type="Hybrid" time="9-10 Wo." rating={4.5} reviews={31} price="9,50 EUR" oldPrice="14,00 EUR" badge={{ text: "-32%", color: "bg-red-500" }} img={PRODUCT_IMG_1} />
              </div>
              <div className="mt-3 flex items-center gap-2">
                <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-2 py-1 rounded">Shop-Modul</span>
                <span className="text-[9px] text-slate-400">Daten vom modified-Core via Smarty, Darstellung via boxes/box_specials.html</span>
              </div>
            </div>

            {/* 08a ZULETZT ANGESEHEN - Shop-Box */}
            <SectionLabel number="08a" title="Zuletzt angesehen ({$box_LAST_VIEWED} - Shop-gesteuert, config: MRH_STARTPAGE_BOX_LAST_VIEWED)" />
            <div className="px-6 py-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-base font-bold text-slate-800" style={{ fontFamily: "var(--font-display)" }}>Zuletzt angesehen</h3>
              </div>
              <div className="flex gap-3">
                {["Amnesia Haze", "White Widow", "Northern Lights", "Gorilla Glue", "Zkittlez OG"].map((name, i) => (
                  <div key={i} className="flex-shrink-0 w-24">
                    <div className="aspect-square bg-slate-100 rounded-lg mb-1 flex items-center justify-center overflow-hidden">
                      <img src={i % 2 === 0 ? PRODUCT_IMG_1 : PRODUCT_IMG_2} alt={name} className="w-full h-full object-cover" />
                    </div>
                    <p className="text-[9px] font-medium text-slate-600 text-center truncate">{name}</p>
                  </div>
                ))}
              </div>
              <div className="mt-3 flex items-center gap-2">
                <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-2 py-1 rounded">Shop-Modul</span>
                <span className="text-[9px] text-slate-400">Daten vom modified-Core, Darstellung via boxes/box_last_viewed.html</span>
              </div>
            </div>

            {/* 09 MARKETING BANNER REIHE 1 */}
            <SectionLabel number="09" title="Marketing-Banner Reihe 1 ({$MAREKTINGQ} + {$MAREKTINGQA})" />
            <div className="px-6 py-4">
              <div className="grid grid-cols-4 gap-4">
                <div className="col-span-1 bg-[#f0fdf4] border border-dashed border-[#4a8c2a]/30 rounded-lg p-4 flex flex-col items-center justify-center text-center">
                  <Package size={16} className="text-[#4a8c2a] mb-2" />
                  <p className="text-[10px] font-semibold text-slate-600">{'{$MAREKTINGQ}'}</p>
                  <p className="text-[9px] text-slate-400">col-md-3</p>
                </div>
                <div className="col-span-3 bg-[#f0fdf4] border border-dashed border-[#4a8c2a]/30 rounded-lg p-4 flex flex-col items-center justify-center text-center">
                  <Package size={16} className="text-[#4a8c2a] mb-2" />
                  <p className="text-[10px] font-semibold text-slate-600">{'{$MAREKTINGQA}'}</p>
                  <p className="text-[9px] text-slate-400">col-md-9</p>
                </div>
              </div>
            </div>

            {/* 10 BESTSELLER CAROUSEL - Shop-Box */}
            <SectionLabel number="10" title="Bestseller Carousel ({$box_BESTSELLERS} - Shop-gesteuert, config: MRH_BSCAROUSEL_SHOW)" />
            <div className="px-6 py-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-slate-800" style={{ fontFamily: "var(--font-display)" }}>Bestseller</h3>
                <a className="text-[#4a8c2a] text-xs font-semibold hover:underline cursor-pointer">Alle anzeigen &raquo;</a>
              </div>
              <div className="grid grid-cols-4 gap-4">
                <ProductCard name="Amnesia Haze" brand="Royal Queen Seeds" thc="22%" type="Sativa 70%" time="10-11 Wo." rating={4.5} reviews={4} price="9,99 EUR" badge={{ text: "Top", color: "bg-[#4a8c2a]" }} img={PRODUCT_IMG_1} />
                <ProductCard name="00 Kush FAST" brand="00 Seeds Bank" thc="22%" type="Indica 90%" time="45-50 T." rating={3.5} reviews={8} price="14,99 EUR" oldPrice="17,50 EUR" badge={{ text: "-15%", color: "bg-red-500" }} img={PRODUCT_IMG_2} />
                <ProductCard name="3 Kingdoms" brand="Freedom Of Seeds" thc="25%" type="Sativa" time="9-11 Wo." rating={0} reviews={0} price="19,20 EUR" img={PRODUCT_IMG_1} />
                <ProductCard name="Aca-Dos Delight" brand="Pure Instinto" thc="25-30%" type="Hybrid" time="8-9 Wo." rating={4} reviews={12} price="22,00 EUR" img={PRODUCT_IMG_2} />
              </div>
              <div className="mt-3 flex items-center gap-2">
                <span className="bg-amber-100 text-amber-800 text-[9px] font-bold px-2 py-1 rounded">Shop-Modul</span>
                <span className="text-[9px] text-slate-400">Daten vom modified-Core via Smarty, Darstellung via boxes/box_best_sellers.html (BS5 Carousel)</span>
              </div>
            </div>

            {/* 10a MARKETING BANNER REIHE 2 */}
            <SectionLabel number="10a" title="Marketing-Banner Reihe 2 ({$MAREKTINGQB} + {$MAREKTINGQC})" />
            <div className="px-6 py-4">
              <div className="grid grid-cols-4 gap-4">
                <div className="col-span-3 bg-[#f0fdf4] border border-dashed border-[#4a8c2a]/30 rounded-lg p-4 flex flex-col items-center justify-center text-center">
                  <Package size={16} className="text-[#4a8c2a] mb-2" />
                  <p className="text-[10px] font-semibold text-slate-600">{'{$MAREKTINGQB}'}</p>
                  <p className="text-[9px] text-slate-400">col-md-9</p>
                </div>
                <div className="col-span-1 bg-[#f0fdf4] border border-dashed border-[#4a8c2a]/30 rounded-lg p-4 flex flex-col items-center justify-center text-center">
                  <Package size={16} className="text-[#4a8c2a] mb-2" />
                  <p className="text-[10px] font-semibold text-slate-600">{'{$MAREKTINGQC}'}</p>
                  <p className="text-[9px] text-slate-400">col-md-3</p>
                </div>
              </div>
            </div>

            {/* 11 FOOTER */}
            <SectionLabel number="11" title="Footer ({$box_CONTENT}, {$box_INFORMATION}, {$box_MISCELLANEOUS} - Shop-Boxen)" />
            <div className="bg-slate-900 text-white px-6 py-8">
              <div className="grid grid-cols-4 gap-6 text-xs">
                <div>
                  <h4 className="font-bold text-sm mb-3" style={{ fontFamily: "var(--font-display)" }}>Informationen</h4>
                  {["Ueber uns", "Versand", "Zahlungsarten", "AGB", "Datenschutz", "Impressum", "Widerrufsrecht"].map((s, i) => (
                    <a key={i} className="block text-slate-400 hover:text-white py-0.5 transition-colors cursor-pointer">{s}</a>
                  ))}
                </div>
                <div>
                  <h4 className="font-bold text-sm mb-3" style={{ fontFamily: "var(--font-display)" }}>Kundenservice</h4>
                  {["Kontakt", "FAQ", "Reklamation", "Rueckgabe", "Briefbestellung"].map((s, i) => (
                    <a key={i} className="block text-slate-400 hover:text-white py-0.5 transition-colors cursor-pointer">{s}</a>
                  ))}
                </div>
                <div>
                  <h4 className="font-bold text-sm mb-3" style={{ fontFamily: "var(--font-display)" }}>Beliebte Kategorien</h4>
                  {["Feminisierte Samen", "Autoflowering", "CBD Samen", "Growshop", "Headshop"].map((s, i) => (
                    <a key={i} className="block text-slate-400 hover:text-white py-0.5 transition-colors cursor-pointer">{s}</a>
                  ))}
                </div>
                <div>
                  <h4 className="font-bold text-sm mb-3" style={{ fontFamily: "var(--font-display)" }}>Sicher einkaufen</h4>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {["Visa", "MC", "PayPal", "Klarna", "BTC"].map((s, i) => (
                      <span key={i} className="bg-slate-800 text-slate-400 text-[10px] px-2 py-1 rounded">{s}</span>
                    ))}
                  </div>
                  <div className="mt-4 border border-dashed border-amber-500/40 rounded-lg p-3 bg-slate-800/50">
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <span className="bg-amber-500/20 text-amber-400 text-[8px] font-bold px-1.5 py-0.5 rounded">Extern / JS</span>
                      <p className="text-amber-300 text-[10px] font-semibold">Trusted Shops</p>
                    </div>
                    <div className="flex gap-0.5 mt-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star key={i} size={10} className="fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                    <p className="text-slate-500 text-[9px] mt-1">4.9/5 (1.234 Bewertungen)</p>
                    <p className="text-slate-600 text-[8px] mt-1.5 leading-relaxed">Dynamisch via widgets.trustedshops.com<br/>(async/defer fuer CWV)</p>
                  </div>

                </div>
              </div>
              <div className="border-t border-slate-800 mt-6 pt-4 text-center text-slate-500 text-[10px]">
                2026 Mr. Hanf - Alle Rechte vorbehalten | modified eCommerce v2.0.7.2 | PHP 8.3
              </div>
            </div>

          </div>

          {/* UPTAIN OVERLAY - seitlich am rechten Rand */}
          <div className="absolute right-0 top-1/2 -translate-y-1/2 z-20">
            <div className="bg-white border-l-4 border-blue-500 shadow-2xl rounded-l-xl p-4 w-48">
              <div className="flex items-center gap-1.5 mb-2">
                <span className="bg-blue-500/20 text-blue-600 text-[7px] font-bold px-1.5 py-0.5 rounded">Extern / JS</span>
              </div>
              <p className="text-blue-700 text-xs font-bold mb-1">Uptain Popup</p>
              <p className="text-slate-500 text-[9px] mb-3 leading-relaxed">Newsletter Slide-in von rechts. Wird dynamisch via Uptain JS geladen.</p>
              <div className="bg-slate-50 rounded-lg p-2.5 border border-slate-200">
                <p className="text-[9px] font-semibold text-slate-700 mb-1">10% Rabatt sichern!</p>
                <div className="flex gap-1">
                  <div className="flex-1 bg-white border border-slate-300 rounded px-2 py-1 text-[8px] text-slate-400">E-Mail...</div>
                  <div className="bg-[#4a8c2a] text-white text-[7px] font-bold px-2 py-1 rounded">OK</div>
                </div>
                <p className="text-[7px] text-slate-400 mt-1">Daten gehen an Brevo</p>
              </div>
              <div className="mt-2 text-center">
                <span className="text-[7px] text-slate-400">async geladen (CWV-safe)</span>
              </div>
            </div>
          </div>

        </div>
      </motion.div>
    </section>
  );
}
