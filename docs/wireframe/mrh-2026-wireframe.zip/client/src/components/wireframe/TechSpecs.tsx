import { motion } from "framer-motion";
import { BarChart3 } from "lucide-react";

const specs = [
  { label: "Framework", old: "Bootstrap 4.6.1", now: "Bootstrap 5.3.x" },
  { label: "CSS", old: "Altes CSS + BS4 Overrides", now: "Komplett neues CSS (kein Legacy)" },
  { label: "JavaScript", old: "jQuery 3.6 + Plugins", now: "Vanilla JS ES2024+ (kein jQuery)" },
  { label: "Komprimierung", old: "BS4_Compactor", now: "Shop-Komprimierung kompatibel" },
  { label: "Icons", old: "Font Awesome 4/5", now: "Font Awesome 6 (beibehalten)" },
  { label: "Sidebar", old: "Linke Sidebar mit 20 Boxen", now: "Keine Sidebar (Option A)" },
  { label: "Mega-Menu", old: "KK-Mega (BS4 jQuery)", now: "KK-Mega (BS5 Vanilla JS)" },
  { label: "Navigation", old: "Pushy.js (extern)", now: "BS5 Offcanvas (nativ)" },
  { label: "Mobile", old: "Responsive (nachtraeglich)", now: "Mobile First Design" },
  { label: "Lazy Loading", old: "lazysizes.js (extern)", now: "Native loading='lazy'" },
  { label: "Bilder", old: "JPG/PNG", now: "WebP/AVIF (via Shop-Modul)" },
  { label: "Schema.org", old: "Basis (Organization)", now: "Product + FAQ + Breadcrumb + AI" },
  { label: "AI Search", old: "Nicht vorhanden", now: "GEO-optimiert (ChatGPT, Perplexity)" },
  { label: "Newsletter", old: "Sidebar-Box", now: "RevPlus-Stil Sektion" },
  { label: "Konfiguration", old: "BS4_ Prefix (config.php)", now: "MRH_ Prefix + JSON-Konfigurator" },
  { label: "Farb-Konfigurator", old: "tpl-Variablen (11 Felder)", now: "mrh-Variablen (21 Felder + Men\u00fc)" },
  { label: "PHP", old: "PHP 7.4+", now: "PHP 8.3" },
  { label: "Shop", old: "modified v2.0.7.2", now: "v2.0.7.2 + modified 3.0 ready" },
];

export default function TechSpecs() {
  return (
    <section id="tech-specs" className="bg-slate-50 py-20">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-white rounded-full px-4 py-1.5 mb-4 border border-slate-200">
              <BarChart3 size={14} className="text-slate-500" />
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider"
                style={{ fontFamily: "var(--font-mono)" }}>Technischer Vergleich</span>
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900" style={{ fontFamily: "var(--font-display)" }}>
              Alt vs. Neu
            </h2>
          </div>
          <div className="max-w-3xl mx-auto bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-lg">
            <div className="grid grid-cols-3 bg-slate-800 text-white text-xs font-semibold">
              <div className="px-4 py-3">Bereich</div>
              <div className="px-4 py-3">Bootstrap 4 (Alt)</div>
              <div className="px-4 py-3 bg-[#4a8c2a]">MRH 2026 (Neu)</div>
            </div>
            {specs.map((row, i) => (
              <div key={i} className={`grid grid-cols-3 text-xs ${i % 2 === 0 ? "bg-white" : "bg-slate-50"} border-b border-slate-100 last:border-0`}>
                <div className="px-4 py-3 font-semibold text-slate-700">{row.label}</div>
                <div className="px-4 py-3 text-slate-500">{row.old}</div>
                <div className="px-4 py-3 text-[#4a8c2a] font-medium">{row.now}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
