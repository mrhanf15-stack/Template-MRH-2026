import { useState } from "react";
import { motion } from "framer-motion";
import {
  CheckCircle, FileCode, Bot, BarChart3, Shield, Gauge,
  ArrowRight
} from "lucide-react";
import { LAYOUT_DIAGRAM, SEO_DIAGRAM } from "./shared";

export default function LayoutAndSeo() {
  const [activeTab, setActiveTab] = useState<"layout" | "seo">("layout");

  return (
    <section id="layout-seo" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-slate-100 rounded-full px-4 py-1.5 mb-4">
              <FileCode size={14} className="text-slate-500" />
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider"
                style={{ fontFamily: "var(--font-mono)" }}>Architektur</span>
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900" style={{ fontFamily: "var(--font-display)" }}>
              Layout &amp; SEO 2026
            </h2>
            <p className="text-slate-500 mt-2 max-w-lg mx-auto">
              Keine Sidebar. Boxen intelligent verteilt. Schema.org und AI-Search optimiert.
            </p>
          </div>

          {/* Tab Toggle */}
          <div className="flex justify-center mb-10">
            <div className="bg-slate-100 rounded-full p-1 flex gap-1">
              <button onClick={() => setActiveTab("layout")}
                className={`px-5 py-2.5 rounded-full text-xs font-semibold transition-colors ${activeTab === "layout" ? "bg-[#4a8c2a] text-white" : "text-slate-500 hover:text-slate-700"}`}>
                Boxen-Verteilung
              </button>
              <button onClick={() => setActiveTab("seo")}
                className={`px-5 py-2.5 rounded-full text-xs font-semibold transition-colors ${activeTab === "seo" ? "bg-[#4a8c2a] text-white" : "text-slate-500 hover:text-slate-700"}`}>
                SEO &amp; Schema.org
              </button>
            </div>
          </div>

          {/* Layout Tab */}
          {activeTab === "layout" && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
              <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-lg">
                  <img src={LAYOUT_DIAGRAM} alt="Startseiten-Layout ohne Sidebar" className="w-full" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 mb-4" style={{ fontFamily: "var(--font-display)" }}>
                    Wohin wandern die Sidebar-Boxen?
                  </h3>
                  <p className="text-sm text-slate-600 mb-6 leading-relaxed">
                    Die klassische linke Sidebar wird komplett entfernt. Alle Boxen werden an die Stellen verschoben, wo sie den groessten Nutzen bringen:
                  </p>
                  <div className="space-y-3">
                    {[
                      { from: "box_CATEGORIES", to: "Hauptnavigation + Mega-Menu", section: "04" },
                      { from: "box_MANUFACTURERS", to: "Mega-Menu Marken + eigene Seite", section: "04a" },
                      { from: "box_BESTSELLERS", to: "Horizontales Carousel auf Startseite", section: "07" },
                      { from: "box_SPECIALS", to: "Horizontales Carousel auf Startseite", section: "08" },
                      { from: "box_WHATSNEW", to: "Horizontales Carousel auf Startseite", section: "07" },
                      { from: "box_LAST_VIEWED", to: "Horizontaler Streifen auf Produktdetailseite", section: "-" },
                      { from: "box_NEWSLETTER", to: "Newsletter-Sektion (RevPlus-Stil)", section: "09" },
                      { from: "box_INFORMATION", to: "Footer Spalte 1", section: "10" },
                      { from: "box_CONTENT", to: "Footer Spalte 2", section: "10" },
                      { from: "box_SHIPPING_COUNTRY", to: "Header (Versandland-Auswahl)", section: "03" },
                      { from: "box_LOGIN", to: "Header-Icon + Offcanvas", section: "03" },
                      { from: "box_ADD_QUICKIE", to: "Warenkorb / Checkout", section: "-" },
                      { from: "box_GIFTCODE", to: "Warenkorb / Checkout", section: "-" },
                    ].map((item, i) => (
                      <div key={i} className="flex items-start gap-3 bg-slate-50 rounded-lg px-4 py-2.5">
                        <CheckCircle size={14} className="text-[#4a8c2a] mt-0.5 flex-shrink-0" />
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <code className="text-[10px] bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded" style={{ fontFamily: "var(--font-mono)" }}>{item.from}</code>
                            <ArrowRight size={10} className="text-slate-400" />
                            <span className="text-xs text-slate-700 font-medium">{item.to}</span>
                          </div>
                        </div>
                        {item.section !== "-" && (
                          <span className="bg-[#4a8c2a] text-white text-[8px] font-bold w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0">{item.section}</span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* SEO Tab */}
          {activeTab === "seo" && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
              <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
                <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-lg">
                  <img src={SEO_DIAGRAM} alt="Schema.org Structured Data Diagram" className="w-full" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 mb-4" style={{ fontFamily: "var(--font-display)" }}>
                    SEO 2026 &amp; AI Search Optimierung
                  </h3>
                  <p className="text-sm text-slate-600 mb-6 leading-relaxed">
                    Das Template wird nicht nur fuer Google, sondern auch fuer AI-Suchmaschinen (ChatGPT, Perplexity, Google AI Overviews) optimiert.
                  </p>
                  <div className="space-y-4">
                    {[
                      { icon: <FileCode size={16} />, title: "Schema.org Structured Data", items: ["Product + Offer + AggregateRating", "Organization + LocalBusiness", "BreadcrumbList auf allen Seiten", "FAQPage fuer Produktbeschreibungen", "ItemList fuer Kategorie-Listings", "WebSite + SearchAction (Sitelinks Search)"] },
                      { icon: <Bot size={16} />, title: "AI Search (GEO) Ready", items: ["Klare Frage-Antwort-Strukturen in Produkttexten", "Zitierbare Fakten (THC, Bluetenzeit, Ertrag)", "Strukturierte Daten fuer AI-Crawling", "Natuerliche Sprache in Meta-Descriptions"] },
                      { icon: <Gauge size={16} />, title: "Core Web Vitals 2026", items: ["LCP < 2.5s (Critical CSS inline)", "INP < 200ms (kein jQuery, Vanilla JS)", "CLS < 0.1 (feste Bildgroessen, Font-Display)", "Native loading='lazy' statt lazysizes.js"] },
                      { icon: <Shield size={16} />, title: "Technisches SEO", items: ["Semantisches HTML5 (header, nav, main, article)", "Canonical URLs + hreflang fuer DE/AT/EU", "robots.txt + XML-Sitemap optimiert", "Preconnect/Preload fuer kritische Ressourcen"] },
                    ].map((group, i) => (
                      <div key={i} className="bg-slate-50 rounded-xl p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-7 h-7 bg-[#e8f5e1] rounded-lg flex items-center justify-center text-[#4a8c2a]">{group.icon}</div>
                          <h4 className="text-sm font-bold text-slate-800" style={{ fontFamily: "var(--font-display)" }}>{group.title}</h4>
                        </div>
                        <ul className="space-y-1">
                          {group.items.map((item, j) => (
                            <li key={j} className="flex items-start gap-2 text-xs text-slate-600">
                              <CheckCircle size={10} className="text-[#4a8c2a] mt-0.5 flex-shrink-0" />
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </motion.div>
      </div>
    </section>
  );
}
