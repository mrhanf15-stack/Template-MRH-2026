import {
  Star, StarHalf, Heart, ShoppingCart, Leaf, Clock, Droplets
} from "lucide-react";

// CDN Assets
export const HERO_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310419663030623217/kxeGuRBrUVHSq5Rr7r3MZW/hero-wireframe-bg-j7cBxzZkJgkouWTV7U9iMJ.webp";
export const PRODUCT_IMG_1 = "https://d2xsxph8kpxj0f.cloudfront.net/310419663030623217/kxeGuRBrUVHSq5Rr7r3MZW/cannabis-product-card-1-Wo5ZovBFXz9tMpFuoznUyf.webp";
export const PRODUCT_IMG_2 = "https://d2xsxph8kpxj0f.cloudfront.net/310419663030623217/kxeGuRBrUVHSq5Rr7r3MZW/cannabis-product-card-2-7zRDptscx986LK3onLggtE.webp";
export const NEWSLETTER_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310419663030623217/kxeGuRBrUVHSq5Rr7r3MZW/newsletter-bg-hddKcVkeCf4VMLaNQAcjaQ.webp";
export const LAYOUT_DIAGRAM = "https://d2xsxph8kpxj0f.cloudfront.net/310419663030623217/kxeGuRBrUVHSq5Rr7r3MZW/startpage-layout-diagram-Ms9aoCZ2HT4hBmM9mVzGR7.webp";
export const SEO_DIAGRAM = "https://d2xsxph8kpxj0f.cloudfront.net/310419663030623217/kxeGuRBrUVHSq5Rr7r3MZW/seo-schema-diagram-Qz49mKoENr4AdjepnuXFXM.webp";
export const MRH_LOGO = "https://d2xsxph8kpxj0f.cloudfront.net/310419663030623217/kxeGuRBrUVHSq5Rr7r3MZW/mrh-logo_bcf65a2b.png";

export const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.1, duration: 0.5, ease: [0, 0, 0.2, 1] as const }
  })
};

export function SectionLabel({ number, title }: { number: string; title: string }) {
  return (
    <div className="flex items-center gap-2 px-4 py-1.5 bg-slate-50/80 border-b border-dashed border-slate-200">
      <span className="bg-[#4a8c2a] text-white text-[9px] font-bold w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
        style={{ fontFamily: "var(--font-mono)" }}>{number}</span>
      <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider"
        style={{ fontFamily: "var(--font-mono)" }}>{title}</span>
    </div>
  );
}

export function Stars({ rating, count }: { rating: number; count: number }) {
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5;
  return (
    <div className="flex items-center gap-1">
      <div className="flex">
        {Array.from({ length: full }).map((_, i) => (
          <Star key={i} size={12} className="fill-amber-400 text-amber-400" />
        ))}
        {half && <StarHalf size={12} className="fill-amber-400 text-amber-400" />}
        {Array.from({ length: 5 - full - (half ? 1 : 0) }).map((_, i) => (
          <Star key={`e${i}`} size={12} className="text-slate-300" />
        ))}
      </div>
      <span className="text-xs text-slate-400">({count})</span>
    </div>
  );
}

export function Badge({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <span className="inline-flex items-center gap-1 bg-[#e8f5e1] text-[#3a7020] text-[10px] font-semibold px-2 py-0.5 rounded-full">
      {icon}{label}
    </span>
  );
}

export function ProductCard({ name, brand, thc, type, time, rating, reviews, price, oldPrice, badge, img }: {
  name: string; brand: string; thc: string; type: string; time: string;
  rating: number; reviews: number; price: string; oldPrice?: string;
  badge?: { text: string; color: string }; img: string;
}) {
  return (
    <div className="bg-white rounded-xl border border-slate-100 overflow-hidden group hover:shadow-lg hover:shadow-green-900/5 transition-all duration-300">
      <div className="relative overflow-hidden">
        {badge && (
          <span className={`absolute top-3 left-3 z-10 text-white text-[10px] font-bold px-2.5 py-1 rounded-md ${badge.color}`}>
            {badge.text}
          </span>
        )}
        <button className="absolute top-3 right-3 z-10 w-8 h-8 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white hover:text-red-500 transition-colors">
          <Heart size={14} />
        </button>
        <div className="aspect-square bg-slate-50 flex items-center justify-center p-4 overflow-hidden">
          <img src={img} alt={name} className="w-full h-full object-cover rounded-lg group-hover:scale-105 transition-transform duration-500" />
        </div>
      </div>
      <div className="p-4">
        <p className="text-[11px] text-slate-400 font-medium mb-0.5">{brand}</p>
        <h3 className="font-semibold text-slate-800 text-sm mb-2 leading-tight" style={{ fontFamily: "var(--font-display)" }}>{name}</h3>
        <div className="flex flex-wrap gap-1 mb-2">
          <Badge icon={<Droplets size={10} />} label={`THC ${thc}`} />
          <Badge icon={<Leaf size={10} />} label={type} />
          <Badge icon={<Clock size={10} />} label={time} />
        </div>
        <Stars rating={rating} count={reviews} />
        <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-100">
          <div className="flex items-baseline gap-1.5">
            <span className="text-xs text-slate-400">ab</span>
            <span className="text-lg font-bold text-[#4a8c2a]" style={{ fontFamily: "var(--font-display)" }}>{price}</span>
            {oldPrice && <span className="text-xs text-slate-400 line-through">{oldPrice}</span>}
          </div>
          <button className="bg-[#4a8c2a] hover:bg-[#3a7020] text-white text-xs font-semibold px-3 py-2 rounded-lg flex items-center gap-1.5 transition-colors">
            <ShoppingCart size={12} /> Warenkorb
          </button>
        </div>
      </div>
    </div>
  );
}

export function MobileProductCard({ name, brand, thc, type, rating, reviews, price, oldPrice, badge, img }: {
  name: string; brand: string; thc: string; type: string;
  rating: number; reviews: number; price: string; oldPrice?: string;
  badge?: { text: string; color: string }; img: string;
}) {
  return (
    <div className="bg-white rounded-lg border border-slate-100 overflow-hidden">
      <div className="relative">
        {badge && (
          <span className={`absolute top-2 left-2 z-10 text-white text-[8px] font-bold px-2 py-0.5 rounded ${badge.color}`}>
            {badge.text}
          </span>
        )}
        <div className="aspect-square bg-slate-50 flex items-center justify-center p-2 overflow-hidden">
          <img src={img} alt={name} className="w-full h-full object-cover rounded" />
        </div>
      </div>
      <div className="p-2.5">
        <p className="text-[9px] text-slate-400 font-medium">{brand}</p>
        <h3 className="font-semibold text-slate-800 text-xs mb-1.5 leading-tight" style={{ fontFamily: "var(--font-display)" }}>{name}</h3>
        <div className="flex flex-wrap gap-0.5 mb-1.5">
          <Badge icon={<Droplets size={8} />} label={`THC ${thc}`} />
          <Badge icon={<Leaf size={8} />} label={type} />
        </div>
        <div className="flex items-center gap-1 mb-1.5">
          <div className="flex">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} size={9} className={i < Math.floor(rating) ? "fill-amber-400 text-amber-400" : "text-slate-300"} />
            ))}
          </div>
          <span className="text-[8px] text-slate-400">({reviews})</span>
        </div>
        <div className="flex items-baseline gap-1 mb-2">
          <span className="text-[9px] text-slate-400">ab</span>
          <span className="text-sm font-bold text-[#4a8c2a]" style={{ fontFamily: "var(--font-display)" }}>{price}</span>
          {oldPrice && <span className="text-[9px] text-slate-400 line-through">{oldPrice}</span>}
        </div>
        <button className="w-full bg-[#4a8c2a] text-white text-[10px] font-semibold py-1.5 rounded flex items-center justify-center gap-1">
          <ShoppingCart size={10} /> Warenkorb
        </button>
      </div>
    </div>
  );
}
