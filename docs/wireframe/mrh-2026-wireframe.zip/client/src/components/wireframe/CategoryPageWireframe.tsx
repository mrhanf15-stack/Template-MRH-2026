/**
 * MRH 2026 Wireframe – Kategorie-Seite v2
 * Komplett überarbeitet:
 * - Details + Vergleich + Merkzettel statt Warenkorb
 * - Live-Smarty-Variablen aus mr-hanf.de (fivebytes Categorie 2)
 * - Subcats: Mobile 2-spaltig, Desktop 6-spaltig
 * - Filter als Modal (Grundfilter sichtbar bleiben)
 * - Kachel- und Listenansicht
 * - Hersteller-Accordion (wie mr-hanf.de Live)
 * - Bootstrap 5.3, Mobile First, SEO 2026
 */
import { useState } from "react";
import { motion } from "framer-motion";
import {
  ChevronRight, ChevronDown, ChevronUp, Grid3X3, List, Filter, X,
  Heart, Star, StarHalf, Eye, Truck, Clock, Leaf, Scale,
  Droplets, Search, SlidersHorizontal,
  Monitor, Smartphone, FileCode, Info, Check, AlertTriangle,
  Layers, Image as ImageIcon, ExternalLink
} from "lucide-react";
import { PRODUCT_IMG_1, PRODUCT_IMG_2, MRH_LOGO } from "./shared";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger
} from "@/components/ui/dialog";

/* ══════════════════════════════════════════
   MOCK DATA
   ══════════════════════════════════════════ */

const BREADCRUMBS = [
  { label: "Startseite", href: "/" },
  { label: "Samen Shop", href: "/samen-shop/" },
  { label: "Autoflowering Samen", href: null },
];

const SUBCATEGORIES = [
  { name: "Feminisierte Samen", count: 342, img: PRODUCT_IMG_1 },
  { name: "Reguläre Samen", count: 89, img: PRODUCT_IMG_2 },
  { name: "Autoflowering Samen", count: 156, img: PRODUCT_IMG_1 },
  { name: "Photoperiodische Samen", count: 214, img: PRODUCT_IMG_2 },
  { name: "CBD Samen", count: 67, img: PRODUCT_IMG_1 },
  { name: "Mix Packs", count: 34, img: PRODUCT_IMG_2 },
];

/* Grundfilter (immer sichtbar) */
const MANUFACTURERS = ["Alle Hersteller", "Royal Queen Seeds", "Barney's Farm", "Fast Buds", "Dutch Passion", "Sensi Seeds"];

/* Erweiterte Filter (nur im Modal) */
const MODAL_FILTERS = [
  { name: "Geschlecht", options: ["Feminisiert (120)", "Regulär (36)", "Autoflowering (89)"] },
  { name: "THC-Gehalt", options: ["< 10% (12)", "10-15% (34)", "15-20% (67)", "20-25% (45)", "> 25% (18)"] },
  { name: "CBD-Gehalt", options: ["< 1% (89)", "1-5% (34)", "5-10% (23)", "> 10% (12)"] },
  { name: "Blütezeit", options: ["6-7 Wochen (23)", "7-8 Wochen (45)", "8-9 Wochen (56)", "9-10 Wochen (32)", "> 10 Wochen (12)"] },
  { name: "Ertrag", options: ["Niedrig (18)", "Mittel (67)", "Hoch (56)", "Sehr hoch (25)"] },
  { name: "Genetik", options: ["Indica (78)", "Sativa (45)", "Hybrid (67)", "Ruderalis (12)"] },
  { name: "Anbau", options: ["Indoor (98)", "Outdoor (67)", "Greenhouse (45)"] },
  { name: "Erfahrung", options: ["Anfänger (56)", "Fortgeschritten (78)", "Experte (34)"] },
];

type ProductData = {
  name: string; brand: string; thc: string; cbd: string; type: string;
  gender: string; time: string; rating: number; reviews: number;
  price: string; oldPrice?: string; badge?: { text: string; color: string };
  img: string; delivery: string; inStock: boolean;
};

const PRODUCTS: ProductData[] = [
  { name: "Purple Haze Auto", brand: "Fast Buds", thc: "19%", cbd: "0.5%", type: "Sativa 80%", gender: "Feminisiert", time: "9-10 Wo.", rating: 4.5, reviews: 23, price: "12,50 EUR", badge: { text: "Bestseller", color: "bg-amber-500" }, img: PRODUCT_IMG_1, delivery: "1-3 Tage", inStock: true },
  { name: "Zkittlez OG Auto", brand: "Barney's Farm", thc: "23%", cbd: "0.3%", type: "Indica 70%", gender: "Autoflowering", time: "8-9 Wo.", rating: 5, reviews: 45, price: "11,00 EUR", img: PRODUCT_IMG_2, delivery: "1-3 Tage", inStock: true },
  { name: "Mimosa EVO", brand: "Barney's Farm", thc: "24%", cbd: "0.1%", type: "Sativa 60%", gender: "Feminisiert", time: "9 Wo.", rating: 4, reviews: 12, price: "13,50 EUR", badge: { text: "Neu", color: "bg-blue-500" }, img: PRODUCT_IMG_1, delivery: "1-3 Tage", inStock: true },
  { name: "Runtz Muffin Auto", brand: "Barney's Farm", thc: "29%", cbd: "0.2%", type: "Indica 60%", gender: "Autoflowering", time: "8-9 Wo.", rating: 4.5, reviews: 31, price: "14,00 EUR", oldPrice: "18,00 EUR", badge: { text: "-22%", color: "bg-red-500" }, img: PRODUCT_IMG_2, delivery: "1-3 Tage", inStock: true },
  { name: "White Widow Auto", brand: "Dutch Passion", thc: "18%", cbd: "0.8%", type: "Hybrid", gender: "Autoflowering", time: "8 Wo.", rating: 4, reviews: 22, price: "7,99 EUR", oldPrice: "12,50 EUR", badge: { text: "-36%", color: "bg-red-500" }, img: PRODUCT_IMG_1, delivery: "1-3 Tage", inStock: true },
  { name: "Northern Lights", brand: "Sensi Seeds", thc: "20%", cbd: "0.5%", type: "Indica", gender: "Feminisiert", time: "7-8 Wo.", rating: 5, reviews: 67, price: "11,50 EUR", img: PRODUCT_IMG_2, delivery: "1-3 Tage", inStock: true },
  { name: "Gorilla Glue Auto", brand: "Fast Buds", thc: "26%", cbd: "0.1%", type: "Hybrid", gender: "Autoflowering", time: "9 Wo.", rating: 4.5, reviews: 18, price: "8,99 EUR", img: PRODUCT_IMG_1, delivery: "1-3 Tage", inStock: true },
  { name: "Girl Scout Cookies", brand: "Fast Buds", thc: "24%", cbd: "0.3%", type: "Hybrid", gender: "Feminisiert", time: "9-10 Wo.", rating: 4.5, reviews: 31, price: "9,50 EUR", badge: { text: "Bestseller", color: "bg-amber-500" }, img: PRODUCT_IMG_2, delivery: "1-3 Tage", inStock: true },
];

const MANUFACTURER = {
  name: "Royal Queen Seeds",
  img: MRH_LOGO,
  shortDesc: "Royal Queen Seeds ist einer der führenden Cannabis-Saatguthersteller Europas. Seit über 10 Jahren entwickelt RQS preisgekrönte Genetiken...",
  fullDesc: "Royal Queen Seeds ist einer der führenden Cannabis-Saatguthersteller Europas. Seit über 10 Jahren entwickelt RQS preisgekrönte Genetiken mit Fokus auf Qualität, Keimrate und Innovation. Das Sortiment umfasst feminisierte, autoflowering und CBD-reiche Sorten. Mit modernsten Zuchtmethoden und strenger Qualitätskontrolle garantiert RQS eine Keimrate von über 95%. Die Samen werden in einer kontrollierten Umgebung in den Niederlanden produziert und weltweit versandt.",
};

const FAQ_ITEMS = [
  { q: "Was sind Autoflowering Samen?", a: "Autoflowering Samen blühen automatisch nach einer bestimmten Zeit, unabhängig vom Lichtzyklus. Sie enthalten Ruderalis-Genetik und sind ideal für Anfänger und schnelle Ernten." },
  { q: "Wie lange dauert die Blütezeit?", a: "Die meisten Autoflowering Sorten sind in 8-10 Wochen von der Keimung bis zur Ernte fertig. Photoperiodische Sorten benötigen je nach Genetik 7-12 Wochen Blütezeit." },
  { q: "Sind Cannabis Samen in Deutschland legal?", a: "Seit April 2024 ist der private Anbau von Cannabis in Deutschland legal. Erwachsene dürfen bis zu 3 Pflanzen für den Eigenbedarf anbauen." },
];

/* ══════════════════════════════════════════
   HELPER COMPONENTS
   ══════════════════════════════════════════ */

function StarsDisplay({ rating, count }: { rating: number; count: number }) {
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5;
  return (
    <div className="flex items-center gap-1">
      <div className="flex">
        {Array.from({ length: full }).map((_, i) => (
          <Star key={i} size={11} className="fill-amber-400 text-amber-400" />
        ))}
        {half && <StarHalf size={11} className="fill-amber-400 text-amber-400" />}
        {Array.from({ length: 5 - full - (half ? 1 : 0) }).map((_, i) => (
          <Star key={`e${i}`} size={11} className="text-slate-300" />
        ))}
      </div>
      <span className="text-[10px] text-slate-400">({count})</span>
    </div>
  );
}

function SmartBadge({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <span className="inline-flex items-center gap-0.5 bg-[#e8f5e1] text-[#3a7020] text-[9px] font-semibold px-1.5 py-0.5 rounded-full">
      {icon}{label}
    </span>
  );
}

function SectionNote({ icon, text, variant = "info" }: { icon: React.ReactNode; text: string; variant?: "info" | "warning" | "success" }) {
  const colors = {
    info: "bg-blue-50 text-blue-700 border-blue-200",
    warning: "bg-amber-50 text-amber-700 border-amber-200",
    success: "bg-green-50 text-green-700 border-green-200",
  };
  return (
    <div className={`flex items-start gap-2 text-[10px] px-3 py-2 rounded-lg border ${colors[variant]}`}>
      <span className="flex-shrink-0 mt-0.5">{icon}</span>
      <span>{text}</span>
    </div>
  );
}

function SectionHeader({ num, label }: { num: string; label: string }) {
  return (
    <div className="flex items-center gap-1 px-4 py-1.5 bg-slate-50/80 border-b border-dashed border-slate-200">
      <span className="bg-[#4a8c2a] text-white text-[9px] font-bold w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
        style={{ fontFamily: "var(--font-mono)" }}>{num}</span>
      <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider"
        style={{ fontFamily: "var(--font-mono)" }}>{label}</span>
    </div>
  );
}

/* ══════════════════════════════════════════
   PRODUCT CARD – GRID VIEW
   Details + Vergleich + Merkzettel (kein Warenkorb)
   ══════════════════════════════════════════ */

function ProductCardGrid({ product }: { product: ProductData }) {
  const [hovered, setHovered] = useState(false);
  const [compared, setCompared] = useState(false);
  const [wishlisted, setWishlisted] = useState(false);

  return (
    <div
      className="bg-white rounded-xl border border-slate-100 overflow-hidden group hover:shadow-lg hover:shadow-green-900/5 transition-all duration-300"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Image */}
      <div className="relative overflow-hidden">
        {product.badge && (
          <span className={`absolute top-2 left-2 z-10 text-white text-[9px] font-bold px-2 py-0.5 rounded-md ${product.badge.color}`}>
            {product.badge.text}
          </span>
        )}
        {/* Wishlist Button (Herz) – oben rechts */}
        <button
          onClick={() => setWishlisted(!wishlisted)}
          className={`absolute top-2 right-2 z-10 w-7 h-7 rounded-full flex items-center justify-center transition-colors ${
            wishlisted ? "bg-red-500 text-white" : "bg-white/80 backdrop-blur-sm text-slate-400 hover:text-red-500 hover:bg-white"
          }`}
          title="Merkzettel"
        >
          <Heart size={12} className={wishlisted ? "fill-white" : ""} />
        </button>
        <div className="aspect-square bg-slate-50 flex items-center justify-center p-3 overflow-hidden">
          <img
            src={hovered ? PRODUCT_IMG_2 : product.img}
            alt={product.name}
            className="w-full h-full object-cover rounded-lg transition-all duration-500"
            style={{ transform: hovered ? "scale(1.05)" : "scale(1)" }}
          />
        </div>
        {hovered && (
          <div className="absolute bottom-1 left-1/2 -translate-x-1/2 bg-black/50 text-white text-[8px] px-2 py-0.5 rounded-full">
            Bild 2/2
          </div>
        )}
      </div>

      {/* Body */}
      <div className="p-3">
        <p className="text-[10px] text-slate-400 font-medium mb-0.5">{product.brand}</p>
        <h3 className="font-semibold text-slate-800 text-xs mb-1.5 leading-tight" style={{ fontFamily: "var(--font-display)" }}>
          {product.name}
        </h3>

        {/* Badges: Gender, THC, CBD, Blütezeit */}
        <div className="flex flex-wrap gap-0.5 mb-1.5">
          <SmartBadge icon={<Leaf size={8} />} label={product.gender} />
          <SmartBadge icon={<Droplets size={8} />} label={`THC ${product.thc}`} />
          {product.cbd !== "0%" && <SmartBadge icon={<Droplets size={8} />} label={`CBD ${product.cbd}`} />}
          <SmartBadge icon={<Clock size={8} />} label={product.time} />
        </div>

        {/* Rating */}
        <StarsDisplay rating={product.rating} count={product.reviews} />

        {/* Delivery */}
        <div className="flex items-center gap-1 mt-1.5">
          <Truck size={10} className="text-green-600" />
          <span className="text-[9px] text-green-600 font-medium">{product.delivery}</span>
        </div>

        {/* Price */}
        <div className="flex items-baseline gap-1 mt-2 pt-2 border-t border-slate-100">
          <span className="text-[9px] text-slate-400">ab</span>
          <span className="text-sm font-bold text-[#4a8c2a]" style={{ fontFamily: "var(--font-display)" }}>{product.price}</span>
          {product.oldPrice && <span className="text-[9px] text-slate-400 line-through">{product.oldPrice}</span>}
        </div>

        {/* Action Buttons: Details + Vergleich + Merkzettel */}
        <div className="flex items-center gap-1 mt-2">
          <button className="flex-1 bg-[#4a8c2a] hover:bg-[#3a7020] text-white text-[9px] font-semibold px-2 py-1.5 rounded-md flex items-center justify-center gap-1 transition-colors">
            <Eye size={10} /> Details
          </button>
          <button
            onClick={() => setCompared(!compared)}
            className={`w-8 h-8 rounded-md flex items-center justify-center transition-colors border ${
              compared
                ? "bg-[#4a8c2a] text-white border-[#4a8c2a]"
                : "border-slate-200 text-slate-400 hover:border-[#4a8c2a] hover:text-[#4a8c2a]"
            }`}
            title={compared ? "Im Vergleich" : "Vergleichen"}
          >
            {compared ? <Check size={12} /> : <Scale size={12} />}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   PRODUCT CARD – LIST VIEW
   ══════════════════════════════════════════ */

function ProductCardList({ product }: { product: ProductData }) {
  const [compared, setCompared] = useState(false);
  const [wishlisted, setWishlisted] = useState(false);

  return (
    <div className="flex gap-3 p-3 bg-white rounded-lg border border-slate-100 hover:shadow-md transition-shadow">
      {/* Image */}
      <div className="relative flex-shrink-0 w-24 h-24 rounded-lg overflow-hidden bg-slate-50">
        {product.badge && (
          <span className={`absolute top-1 left-1 z-10 text-white text-[7px] font-bold px-1.5 py-0.5 rounded ${product.badge.color}`}>
            {product.badge.text}
          </span>
        )}
        <img src={product.img} alt={product.name} className="w-full h-full object-cover" />
      </div>

      {/* Info */}
      <div className="flex-grow min-w-0">
        <p className="text-[9px] text-slate-400 font-medium">{product.brand}</p>
        <h3 className="font-semibold text-slate-800 text-xs mb-1 leading-tight truncate" style={{ fontFamily: "var(--font-display)" }}>
          {product.name}
        </h3>
        <div className="flex flex-wrap gap-0.5 mb-1">
          <SmartBadge icon={<Leaf size={7} />} label={product.gender} />
          <SmartBadge icon={<Droplets size={7} />} label={`THC ${product.thc}`} />
          <SmartBadge icon={<Clock size={7} />} label={product.time} />
        </div>
        <StarsDisplay rating={product.rating} count={product.reviews} />
        <div className="flex items-center gap-1 mt-1">
          <Truck size={9} className="text-green-600" />
          <span className="text-[8px] text-green-600 font-medium">{product.delivery}</span>
        </div>
      </div>

      {/* Price + Actions */}
      <div className="flex flex-col items-end justify-between flex-shrink-0">
        <div className="text-right">
          <span className="text-[8px] text-slate-400">ab</span>
          <div className="text-sm font-bold text-[#4a8c2a]" style={{ fontFamily: "var(--font-display)" }}>{product.price}</div>
          {product.oldPrice && <span className="text-[9px] text-slate-400 line-through">{product.oldPrice}</span>}
        </div>
        <div className="flex items-center gap-1">
          <button className="bg-[#4a8c2a] hover:bg-[#3a7020] text-white text-[8px] font-semibold px-2 py-1.5 rounded-md flex items-center gap-1 transition-colors">
            <Eye size={9} /> Details
          </button>
          <button
            onClick={() => setCompared(!compared)}
            className={`w-7 h-7 rounded-md flex items-center justify-center transition-colors border ${
              compared ? "bg-[#4a8c2a] text-white border-[#4a8c2a]" : "border-slate-200 text-slate-400 hover:border-[#4a8c2a] hover:text-[#4a8c2a]"
            }`}
            title="Vergleichen"
          >
            {compared ? <Check size={10} /> : <Scale size={10} />}
          </button>
          <button
            onClick={() => setWishlisted(!wishlisted)}
            className={`w-7 h-7 rounded-md flex items-center justify-center transition-colors border ${
              wishlisted ? "bg-red-500 text-white border-red-500" : "border-slate-200 text-slate-400 hover:border-red-400 hover:text-red-500"
            }`}
            title="Merkzettel"
          >
            <Heart size={10} className={wishlisted ? "fill-white" : ""} />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   FILTER MODAL CONTENT
   ══════════════════════════════════════════ */

function FilterModalContent() {
  const [openFilter, setOpenFilter] = useState<number | null>(0);
  return (
    <div className="space-y-0">
      {MODAL_FILTERS.map((filter, idx) => (
        <div key={idx} className="border-b border-slate-100 last:border-0">
          <button
            className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-slate-50 transition-colors"
            onClick={() => setOpenFilter(openFilter === idx ? null : idx)}
          >
            <span className="text-xs font-semibold text-slate-700">{filter.name}</span>
            {openFilter === idx ? <ChevronUp size={14} className="text-slate-400" /> : <ChevronDown size={14} className="text-slate-400" />}
          </button>
          {openFilter === idx && (
            <div className="px-4 pb-3 space-y-1.5">
              {filter.options.map((opt, oi) => (
                <label key={oi} className="flex items-center gap-2 cursor-pointer group">
                  <input type="checkbox" className="w-3.5 h-3.5 rounded accent-[#4a8c2a]" />
                  <span className="text-[11px] text-slate-600 group-hover:text-slate-800">{opt}</span>
                </label>
              ))}
            </div>
          )}
        </div>
      ))}
      {/* Footer */}
      <div className="p-4 border-t border-slate-200 flex gap-3">
        <button className="flex-1 text-xs font-medium text-slate-500 border border-slate-200 py-2 rounded-lg hover:bg-slate-50 transition-colors">
          Zurücksetzen
        </button>
        <button className="flex-1 text-xs font-semibold text-white bg-[#4a8c2a] py-2 rounded-lg hover:bg-[#3a7020] transition-colors">
          Filter anwenden
        </button>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   MAIN COMPONENT
   ══════════════════════════════════════════ */

export default function CategoryPageWireframe() {
  const [activeTab, setActiveTab] = useState<"desktop" | "mobile">("desktop");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [showManufacturer, setShowManufacturer] = useState(true);
  const [manuExpanded, setManuExpanded] = useState(false);
  const [showMobileFilter, setShowMobileFilter] = useState(false);

  return (
    <section id="category-page-wireframe" className="py-20 bg-gradient-to-b from-white to-slate-50/50">
      <motion.div className="container max-w-6xl" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, ease: [0, 0, 0.2, 1] }}>
        {/* Section Title */}
        <div className="text-center mb-10">
          <span className="text-[10px] font-bold text-[#4a8c2a] uppercase tracking-[0.2em] mb-2 block"
            style={{ fontFamily: "var(--font-mono)" }}>Wireframe v2</span>
          <h2 className="text-3xl font-black text-slate-900 mb-3" style={{ fontFamily: "var(--font-display)" }}>
            Kategorie-Seite & Produktlisting
          </h2>
          <p className="text-sm text-slate-500 max-w-2xl mx-auto">
            Komplett überarbeiteter Wireframe mit Live-Smarty-Variablen aus mr-hanf.de,
            fivebytes Kategorie-Erweiterungen, Filter-Modal und Details/Vergleich/Merkzettel-Buttons.
          </p>
        </div>

        {/* Tab Toggle: Desktop / Mobile */}
        <div className="flex justify-center gap-2 mb-8">
          {[
            { key: "desktop" as const, icon: <Monitor size={14} />, label: "Desktop" },
            { key: "mobile" as const, icon: <Smartphone size={14} />, label: "Mobile" },
          ].map(t => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold transition-all ${
                activeTab === t.key
                  ? "bg-[#4a8c2a] text-white shadow-md"
                  : "bg-white text-slate-500 border border-slate-200 hover:border-[#4a8c2a] hover:text-[#4a8c2a]"
              }`}
            >
              {t.icon}{t.label}
            </button>
          ))}
        </div>

        {/* ══════════════════════════════════════
           DESKTOP VIEW
           ══════════════════════════════════════ */}
        {activeTab === "desktop" && (
          <div className="max-w-5xl mx-auto">
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">

              {/* ── 01 BREADCRUMB ── */}
              <SectionHeader num="01" label="Breadcrumb (BreadcrumbList Schema)" />
              <div className="px-6 py-2 border-b border-slate-100">
                <nav className="flex items-center gap-1 text-[10px]" aria-label="Breadcrumb">
                  {BREADCRUMBS.map((bc, i) => (
                    <span key={i} className="flex items-center gap-1">
                      {i > 0 && <ChevronRight size={10} className="text-slate-300" />}
                      {bc.href ? (
                        <span className="text-[#4a8c2a] hover:underline cursor-pointer">{bc.label}</span>
                      ) : (
                        <span className="text-slate-600 font-medium">{bc.label}</span>
                      )}
                    </span>
                  ))}
                </nav>
              </div>

              {/* ── 02 KATEGORIE-HEADER (Bild links + H1 + Slider optional) ── */}
              <SectionHeader num="02" label="Kategorie-Header (H1 + Bild + Slider + Kurzbeschreibung)" />
              <div className="px-6 py-4 border-b border-slate-100">
                {/* Slider Placeholder */}
                <div className="bg-slate-50 border border-dashed border-slate-200 rounded-lg p-3 mb-3 flex items-center justify-center gap-2">
                  <ImageIcon size={14} className="text-slate-300" />
                  <span className="text-[10px] text-slate-400 italic">Optional: {"{$SLIDER}"} – Kategorie-Slider (nur Seite 1)</span>
                </div>
                {/* H1 + Bild kompakt */}
                <div className="flex items-center gap-4 mb-3">
                  <div className="w-20 h-20 rounded-xl overflow-hidden bg-slate-100 flex-shrink-0 border border-slate-200">
                    <img src={PRODUCT_IMG_1} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h1 className="text-xl font-black text-slate-900" style={{ fontFamily: "var(--font-display)" }}>
                      Autoflowering Samen
                    </h1>
                    <p className="text-[11px] text-slate-500 mt-1 leading-relaxed max-w-xl">
                      Autoflowering Cannabis Samen blühen automatisch und sind ideal für Anfänger.
                      Schnelle Ernte in 8-10 Wochen, kompakte Pflanzen, pflegeleicht.
                    </p>
                  </div>
                </div>
                {/* Zweites Kategoriebild (fivebytes) */}
                <div className="bg-amber-50 border border-dashed border-amber-200 rounded-lg p-2 flex items-center gap-2">
                  <ImageIcon size={12} className="text-amber-400" />
                  <span className="text-[9px] text-amber-600 italic">
                    fivebytes: {"{$CATEGORIES_IMAGE_2}"} – Zweites Kategoriebild (float-right, nur Seite 1)
                  </span>
                </div>
                <SectionNote
                  icon={<Info size={10} />}
                  text="Smarty: {$LIST_TITLE} oder {$CATEGORIES_HEADING_TITLE}, {$CATEGORIES_IMAGE} + {$CATEGORIES_IMAGE_MOBILE} (picture/source), {$CATEGORIES_SHORT_DESCRIPTION}. Bild kompakt links neben H1. Nur auf Seite 1: {if empty($smarty.get.page) || $smarty.get.page < 2}."
                  variant="info"
                />
              </div>

              {/* ── 03 UNTERKATEGORIEN (6-spaltig Desktop) ── */}
              <SectionHeader num="03" label="Unterkategorien (Mobile 2-spaltig, Desktop 6-spaltig)" />
              <div className="px-6 py-4 border-b border-slate-100">
                <div className="grid grid-cols-6 gap-2">
                  {SUBCATEGORIES.map((cat, i) => (
                    <div key={i} className="bg-slate-50 rounded-lg p-2 flex flex-col items-center gap-1.5 hover:bg-[#e8f5e1] hover:border-[#4a8c2a] border border-transparent cursor-pointer transition-all group">
                      <div className="w-12 h-12 rounded-lg overflow-hidden bg-white border border-slate-100">
                        <img src={cat.img} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                      </div>
                      <span className="text-[9px] font-semibold text-slate-700 text-center leading-tight group-hover:text-[#3a7020]">{cat.name}</span>
                      <span className="text-[8px] text-slate-400">({cat.count})</span>
                    </div>
                  ))}
                </div>
                {/* contentAnywhere */}
                <div className="mt-3 bg-slate-50 border border-dashed border-slate-200 rounded-lg p-2 flex items-center gap-2">
                  <ExternalLink size={10} className="text-slate-300" />
                  <span className="text-[9px] text-slate-400 italic">{"{1003236|contentAnywhere|inserttags}"} – Dynamischer Content-Block</span>
                </div>
                <SectionNote
                  icon={<Info size={10} />}
                  text="Smarty: {$CATEGORIES_LISTING}. Responsive: col-6 (Mobile 2-spaltig), col-md-4 (Tablet 3), col-lg-2 (Desktop 6-spaltig). Nur auf Seite 1."
                  variant="info"
                />
              </div>

              {/* ── 04 GRUNDFILTER + FILTER-MODAL ── */}
              <SectionHeader num="04" label="Grundfilter (sichtbar) + Erweiterte Filter (Modal)" />
              <div className="px-6 py-3 border-b border-slate-100">
                <div className="flex items-center gap-2 flex-wrap">
                  {/* Kachel/Liste Toggle */}
                  <div className="flex gap-0.5 bg-slate-100 rounded-md p-0.5">
                    <button
                      onClick={() => setViewMode("grid")}
                      className={`p-1.5 rounded ${viewMode === "grid" ? "bg-white shadow-sm text-[#4a8c2a]" : "text-slate-400 hover:text-slate-600"}`}
                      title="Kachelansicht"
                    >
                      <Grid3X3 size={14} />
                    </button>
                    <button
                      onClick={() => setViewMode("list")}
                      className={`p-1.5 rounded ${viewMode === "list" ? "bg-white shadow-sm text-[#4a8c2a]" : "text-slate-400 hover:text-slate-600"}`}
                      title="Listenansicht"
                    >
                      <List size={14} />
                    </button>
                  </div>

                  {/* Filter-Modal Button */}
                  <Dialog>
                    <DialogTrigger asChild>
                      <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs text-slate-600 hover:border-[#4a8c2a] hover:text-[#4a8c2a] transition-colors">
                        <SlidersHorizontal size={13} />
                        <span className="font-medium">Filter</span>
                        <span className="bg-[#4a8c2a] text-white text-[8px] font-bold w-4 h-4 rounded-full flex items-center justify-center">3</span>
                      </button>
                    </DialogTrigger>
                    <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto p-0">
                      <DialogHeader className="px-4 py-3 border-b border-slate-200 sticky top-0 bg-white z-10">
                        <DialogTitle className="text-sm font-bold flex items-center gap-2">
                          <SlidersHorizontal size={16} className="text-[#4a8c2a]" />
                          Erweiterte Filter
                        </DialogTitle>
                      </DialogHeader>
                      <FilterModalContent />
                    </DialogContent>
                  </Dialog>

                  {/* Hersteller Dropdown */}
                  <select className="text-[11px] border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white text-slate-600 hover:border-[#4a8c2a] transition-colors">
                    {MANUFACTURERS.map((m, i) => <option key={i}>{m}</option>)}
                  </select>

                  {/* Sortierung */}
                  <select className="text-[11px] border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white text-slate-600 hover:border-[#4a8c2a] transition-colors">
                    <option>Preis aufsteigend</option>
                    <option>Preis absteigend</option>
                    <option>Name A-Z</option>
                    <option>Bewertung</option>
                    <option>Neueste</option>
                  </select>

                  {/* Artikel pro Seite */}
                  <select className="text-[11px] border border-slate-200 rounded-lg px-2.5 py-1.5 bg-white text-slate-600 hover:border-[#4a8c2a] transition-colors">
                    <option>20 pro Seite</option>
                    <option>40 pro Seite</option>
                    <option>60 pro Seite</option>
                  </select>

                  {/* Counter */}
                  <span className="text-[10px] text-slate-400 ml-auto">
                    Zeige <strong className="text-slate-700">1</strong> bis <strong className="text-slate-700">20</strong> von <strong className="text-[#4a8c2a]">156</strong> Artikeln
                  </span>
                </div>
                <SectionNote
                  icon={<Info size={10} />}
                  text="Grundfilter sichtbar: Kachel/Liste-Toggle, Filter-Icon (öffnet Modal mit Seedfinder-Filtern), Hersteller-Dropdown, Sortierung, Artikel pro Seite. Alle erweiterten Filter (Geschlecht, THC, Blütezeit, Ertrag, Genetik, Anbau, Erfahrung) nur im Modal."
                  variant="info"
                />
              </div>

              {/* ── 05 HERSTELLER-BEREICH (Accordion) ── */}
              <SectionHeader num="05" label="Hersteller-Bereich (Accordion, nur bei Hersteller-Listings)" />
              <div className="px-6 py-3 border-b border-slate-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] text-slate-400">Hersteller-Bereich ein/aus:</span>
                  <button
                    onClick={() => setShowManufacturer(!showManufacturer)}
                    className={`text-[9px] px-2 py-0.5 rounded-full border ${showManufacturer ? "bg-[#e8f5e1] text-[#3a7020] border-[#4a8c2a]" : "bg-slate-50 text-slate-400 border-slate-200"}`}
                  >
                    {showManufacturer ? "Sichtbar" : "Ausgeblendet"}
                  </button>
                </div>
                {showManufacturer && (
                  <div className="bg-[#f8faf6] rounded-xl border border-slate-200 overflow-hidden">
                    {/* Header */}
                    <div className="flex items-start gap-4 p-4">
                      <div className="flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden bg-white border border-slate-100 flex items-center justify-center p-1">
                        <img src={MANUFACTURER.img} alt={MANUFACTURER.name} className="w-full h-full object-contain" />
                      </div>
                      <div className="flex-grow">
                        <h4 className="text-sm font-bold text-slate-800 mb-1" style={{ fontFamily: "var(--font-display)" }}>
                          {MANUFACTURER.name}
                        </h4>
                        {!manuExpanded && (
                          <p className="text-[11px] text-slate-500 leading-relaxed">{MANUFACTURER.shortDesc}</p>
                        )}
                        {manuExpanded && (
                          <p className="text-[11px] text-slate-500 leading-relaxed">{MANUFACTURER.fullDesc}</p>
                        )}
                        <button
                          onClick={() => setManuExpanded(!manuExpanded)}
                          className="text-[10px] text-[#4a8c2a] font-semibold mt-1 hover:underline flex items-center gap-0.5"
                        >
                          {manuExpanded ? "Weniger anzeigen" : "Alles anzeigen"}
                          {manuExpanded ? <ChevronUp size={10} /> : <ChevronDown size={10} />}
                        </button>
                      </div>
                    </div>
                    <SectionNote
                      icon={<Info size={10} />}
                      text="Smarty: {$MANUFACTURER_NAME}, {$MANUFACTURER_IMAGE}, {$MANUFACTURER_SHORT_DESCRIPTION|truncate:250}, {$MANUFACTURER_DESCRIPTION}. Bootstrap Accordion (data-bs-toggle='collapse'). Nur sichtbar wenn Hersteller-Daten vorhanden. Nur Seite 1."
                      variant="info"
                    />
                  </div>
                )}
              </div>

              {/* ── 06 PAGINATION OBEN ── */}
              <SectionHeader num="06" label="Pagination oben (bereits implementiert)" />
              <div className="px-6 py-2 border-b border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-400">
                    Zeige <strong className="text-slate-700">1</strong> bis <strong className="text-slate-700">20</strong> von <strong className="text-[#4a8c2a]">156</strong> Artikeln
                  </span>
                  <div className="flex gap-0.5">
                    <span className="w-6 h-6 flex items-center justify-center rounded bg-[#4a8c2a] text-white text-[10px] font-bold">1</span>
                    <span className="w-6 h-6 flex items-center justify-center rounded border border-slate-200 text-[10px] text-slate-500 hover:border-[#4a8c2a] cursor-pointer">2</span>
                    <span className="w-6 h-6 flex items-center justify-center rounded border border-slate-200 text-[10px] text-slate-500 hover:border-[#4a8c2a] cursor-pointer">3</span>
                    <span className="w-6 h-6 flex items-center justify-center text-[10px] text-slate-400">...</span>
                    <span className="w-6 h-6 flex items-center justify-center rounded border border-slate-200 text-[10px] text-slate-500 hover:border-[#4a8c2a] cursor-pointer">8</span>
                  </div>
                </div>
              </div>

              {/* ── 07 PRODUKT-GRID / LISTE ── */}
              <SectionHeader num="07" label={`Produktlisting (${viewMode === "grid" ? "Grid 4-spaltig" : "Listenansicht"} – Details/Vergleich/Merkzettel)`} />
              <div className="px-6 py-4">
                {viewMode === "grid" ? (
                  <div className="grid grid-cols-4 gap-3">
                    {PRODUCTS.map((p, i) => (
                      <ProductCardGrid key={i} product={p} />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2">
                    {PRODUCTS.map((p, i) => (
                      <ProductCardList key={i} product={p} />
                    ))}
                  </div>
                )}
                <div className="mt-3 space-y-1.5">
                  <SectionNote
                    icon={<Info size={10} />}
                    text="Kein Warenkorb-Button! Stattdessen: Details (Auge, btn-outline-success), Vergleich (Waage, btn-compare btn-outline-secondary, aus ProductCompare-Repo), Merkzettel (Herz, PRODUCTS_LINK_WISHLIST_NOW). Farben über Admin-Konfigurator steuerbar."
                    variant="info"
                  />
                  <SectionNote
                    icon={<FileCode size={10} />}
                    text="Smarty: {foreach item=product_data from=$module_content}. Grid: col-6 col-md-4 col-lg-3. Vergleich: {if defined('MODULE_PRODUCT_COMPARE_STATUS') && $smarty.const.MODULE_PRODUCT_COMPARE_STATUS == 'true'}. Merkzettel: {$module_data.PRODUCTS_LINK_WISHLIST_NOW}."
                    variant="success"
                  />
                </div>
              </div>

              {/* ── 08 PAGINATION UNTEN ── */}
              <SectionHeader num="08" label="Pagination unten (pagination.html – bereits implementiert)" />
              <div className="px-6 py-4 border-b border-slate-100">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-400">
                    Zeige <strong className="text-slate-700">1</strong> bis <strong className="text-slate-700">20</strong> von <strong className="text-[#4a8c2a]">156</strong> Artikeln
                  </span>
                  <div className="flex items-center gap-1">
                    <button className="w-7 h-7 flex items-center justify-center rounded border border-slate-200 text-slate-300 cursor-not-allowed">
                      <ChevronRight size={14} className="rotate-180" />
                    </button>
                    {[1,2,3,4,5].map(n => (
                      <button key={n} className={`w-7 h-7 flex items-center justify-center rounded text-[11px] font-semibold transition-colors ${
                        n === 1 ? "bg-[#4a8c2a] text-white" : "border border-slate-200 text-slate-600 hover:border-[#4a8c2a] hover:text-[#4a8c2a]"
                      }`}>{n}</button>
                    ))}
                    <span className="text-[10px] text-slate-400 px-1">...</span>
                    <button className="w-7 h-7 flex items-center justify-center rounded border border-slate-200 text-slate-600 hover:border-[#4a8c2a] text-[11px] font-semibold">8</button>
                    <button className="w-7 h-7 flex items-center justify-center rounded border border-slate-200 text-slate-600 hover:border-[#4a8c2a]">
                      <ChevronRight size={14} />
                    </button>
                  </div>
                </div>
                <SectionNote
                  icon={<Check size={10} />}
                  text="Bereits implementiert: pagination.html + pagination_layout.css + pagination.js. rel=prev/next, aria-labels, Keyboard-Navigation, Scroll-to-top, Prefetch."
                  variant="success"
                />
              </div>

              {/* ── 09 SEO-BESCHREIBUNG + FAQ ── */}
              <SectionHeader num="09" label="Kategorie-Beschreibung + FAQ (SEO 2026, nur Seite 1)" />
              <div className="px-6 py-4 border-b border-slate-100">
                <div className="prose-sm max-w-none">
                  <h2 className="text-base font-bold text-slate-800 mb-2" style={{ fontFamily: "var(--font-display)" }}>
                    Autoflowering Samen kaufen – Der ultimative Guide
                  </h2>
                  <p className="text-[11px] text-slate-600 leading-relaxed mb-3">
                    Autoflowering Cannabis Samen sind die perfekte Wahl für Anfänger und erfahrene Grower gleichermaßen.
                    Dank ihrer Ruderalis-Genetik blühen diese Sorten automatisch nach 2-4 Wochen, unabhängig vom Lichtzyklus.
                    Bei Mr. Hanf findest du über 150 Autoflowering Sorten von renommierten Herstellern.
                  </p>

                  <h3 className="text-xs font-bold text-slate-700 mb-1.5" style={{ fontFamily: "var(--font-display)" }}>
                    Vorteile von Autoflowering Samen
                  </h3>
                  <ul className="text-[11px] text-slate-600 space-y-1 mb-3 pl-4">
                    <li className="list-disc">Schnelle Ernte: 8-10 Wochen von Keimung bis Ernte</li>
                    <li className="list-disc">Kompakte Größe: Ideal für begrenzten Platz</li>
                    <li className="list-disc">Pflegeleicht: Kein Lichtzyklus-Management nötig</li>
                    <li className="list-disc">Mehrere Ernten pro Saison möglich</li>
                  </ul>

                  {/* fivebytes: Zweiter Beschreibungstext */}
                  <div className="bg-amber-50 border border-dashed border-amber-200 rounded-lg p-2 mb-3 flex items-center gap-2">
                    <AlertTriangle size={10} className="text-amber-400" />
                    <span className="text-[9px] text-amber-600 italic">
                      fivebytes: {"{$CATEGORIES_DESCRIPTION_2}"} – Zweiter Beschreibungstext (nur wenn Short + Full vorhanden, Seite 1)
                    </span>
                  </div>

                  {/* FAQ Section */}
                  <h3 className="text-xs font-bold text-slate-700 mb-2 mt-4" style={{ fontFamily: "var(--font-display)" }}>
                    Häufig gestellte Fragen
                  </h3>
                  <div className="space-y-1.5">
                    {FAQ_ITEMS.map((faq, i) => (
                      <div key={i} className="border border-slate-200 rounded-lg overflow-hidden">
                        <div className="px-3 py-2 bg-slate-50 flex items-center justify-between cursor-pointer">
                          <span className="text-[11px] font-semibold text-slate-700">{faq.q}</span>
                          <ChevronDown size={12} className="text-slate-400" />
                        </div>
                        <div className="px-3 py-2 border-t border-slate-100">
                          <p className="text-[10px] text-slate-500 leading-relaxed">{faq.a}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Blog Search Results */}
                  <div className="mt-3 bg-slate-50 border border-dashed border-slate-200 rounded-lg p-2 flex items-center gap-2">
                    <Search size={10} className="text-slate-300" />
                    <span className="text-[9px] text-slate-400 italic">{"{$BLOG_SEARCH_RESULTS}"} – Blog-Suchergebnisse (optional)</span>
                  </div>
                </div>
                <div className="mt-3 space-y-1.5">
                  <SectionNote
                    icon={<Info size={10} />}
                    text="Smarty: {$CATEGORIES_DESCRIPTION}, {$CATEGORIES_DESCRIPTION_2} (fivebytes). Immer voll sichtbar mit H2/H3-Struktur. FAQ am Ende für Featured Snippets + AI Search. Nur auf Seite 1."
                    variant="info"
                  />
                  <SectionNote
                    icon={<FileCode size={10} />}
                    text="Schema: FAQPage mit Question/Answer. Blog-Ergebnisse: {$BLOG_SEARCH_RESULTS}. Seite-1-Check: {if empty($smarty.get.page) || $smarty.get.page < 2}."
                    variant="success"
                  />
                </div>
              </div>

            </div>
          </div>
        )}

        {/* ══════════════════════════════════════
           MOBILE VIEW
           ══════════════════════════════════════ */}
        {activeTab === "mobile" && (
          <div className="max-w-sm mx-auto">
            <div className="bg-slate-900 rounded-[2.5rem] p-3 shadow-2xl">
              <div className="bg-white rounded-[2rem] overflow-hidden relative" style={{ height: "720px" }}>
                {/* Status Bar */}
                <div className="bg-slate-800 text-white text-[8px] px-4 py-1 flex justify-between">
                  <span>9:41</span>
                  <div className="flex gap-1"><span>5G</span><span>100%</span></div>
                </div>

                {/* Scrollable Content */}
                <div className="overflow-y-auto" style={{ height: "700px" }}>
                  {/* Breadcrumb */}
                  <div className="px-3 py-1.5 border-b border-slate-100">
                    <div className="flex items-center gap-0.5 text-[8px] text-slate-400 overflow-x-auto whitespace-nowrap">
                      <span className="text-[#4a8c2a]">Start</span>
                      <ChevronRight size={8} />
                      <span className="text-[#4a8c2a]">Samen</span>
                      <ChevronRight size={8} />
                      <span className="text-slate-600 font-medium">Autoflowering</span>
                    </div>
                  </div>

                  {/* H1 + Bild */}
                  <div className="px-3 py-2 flex items-center gap-2">
                    <div className="w-12 h-12 rounded-lg overflow-hidden bg-slate-100 flex-shrink-0">
                      <img src={PRODUCT_IMG_1} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <h1 className="text-sm font-bold text-slate-900" style={{ fontFamily: "var(--font-display)" }}>
                        Autoflowering Samen
                      </h1>
                      <p className="text-[8px] text-slate-400">156 Artikel</p>
                    </div>
                  </div>

                  {/* Subcategories (2-spaltig Mobile) */}
                  <div className="px-3 py-2">
                    <div className="grid grid-cols-2 gap-1.5">
                      {SUBCATEGORIES.map((cat, i) => (
                        <div key={i} className="bg-slate-50 rounded-lg p-1.5 flex items-center gap-1.5">
                          <div className="w-8 h-8 rounded overflow-hidden flex-shrink-0">
                            <img src={cat.img} alt="" className="w-full h-full object-cover" />
                          </div>
                          <div>
                            <span className="text-[8px] font-semibold text-slate-700 block leading-tight">{cat.name}</span>
                            <span className="text-[7px] text-slate-400">({cat.count})</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Grundfilter Mobile */}
                  <div className="px-3 py-1.5 border-y border-slate-100 flex items-center gap-1.5">
                    {/* Kachel/Liste */}
                    <div className="flex gap-0.5 bg-slate-100 rounded p-0.5">
                      <button className={`p-1 rounded ${viewMode === "grid" ? "bg-white shadow-sm" : ""}`}>
                        <Grid3X3 size={10} className="text-slate-500" />
                      </button>
                      <button className={`p-1 rounded ${viewMode === "list" ? "bg-white shadow-sm" : ""}`}>
                        <List size={10} className="text-slate-500" />
                      </button>
                    </div>
                    {/* Filter Modal Button */}
                    <button
                      onClick={() => setShowMobileFilter(true)}
                      className="flex items-center gap-1 px-2 py-1 rounded border border-slate-200 text-[8px] text-slate-600"
                    >
                      <SlidersHorizontal size={9} />
                      <span>Filter</span>
                      <span className="bg-[#4a8c2a] text-white text-[7px] w-3.5 h-3.5 rounded-full flex items-center justify-center">3</span>
                    </button>
                    {/* Sortierung */}
                    <select className="text-[8px] border border-slate-200 rounded px-1 py-1 bg-white text-slate-600 flex-1">
                      <option>Sortierung</option>
                    </select>
                  </div>

                  {/* Product Grid (2-spaltig Mobile) */}
                  <div className="px-3 py-2">
                    <div className="grid grid-cols-2 gap-1.5">
                      {PRODUCTS.slice(0, 4).map((p, i) => (
                        <div key={i} className="bg-white rounded-lg border border-slate-100 overflow-hidden">
                          <div className="relative">
                            {p.badge && (
                              <span className={`absolute top-1 left-1 z-10 text-white text-[7px] font-bold px-1 py-0.5 rounded ${p.badge.color}`}>
                                {p.badge.text}
                              </span>
                            )}
                            <button className="absolute top-1 right-1 z-10 w-5 h-5 bg-white/80 rounded-full flex items-center justify-center">
                              <Heart size={8} className="text-slate-400" />
                            </button>
                            <div className="aspect-square bg-slate-50 p-1.5">
                              <img src={p.img} alt={p.name} className="w-full h-full object-cover rounded" />
                            </div>
                          </div>
                          <div className="p-1.5">
                            <p className="text-[7px] text-slate-400">{p.brand}</p>
                            <h3 className="text-[9px] font-semibold text-slate-800 leading-tight mb-0.5">{p.name}</h3>
                            <div className="flex flex-wrap gap-0.5 mb-0.5">
                              <span className="text-[7px] bg-[#e8f5e1] text-[#3a7020] px-1 py-0.5 rounded-full">{p.gender}</span>
                              <span className="text-[7px] bg-[#e8f5e1] text-[#3a7020] px-1 py-0.5 rounded-full">THC {p.thc}</span>
                            </div>
                            <div className="flex items-center gap-0.5 mb-0.5">
                              {Array.from({ length: 5 }).map((_, si) => (
                                <Star key={si} size={7} className={si < Math.floor(p.rating) ? "fill-amber-400 text-amber-400" : "text-slate-300"} />
                              ))}
                              <span className="text-[7px] text-slate-400">({p.reviews})</span>
                            </div>
                            <div className="flex items-center justify-between mt-1">
                              <span className="text-[10px] font-bold text-[#4a8c2a]">{p.price}</span>
                            </div>
                            {/* Mobile Actions: Details + Vergleich */}
                            <div className="flex items-center gap-1 mt-1">
                              <button className="flex-1 bg-[#4a8c2a] text-white text-[7px] font-semibold py-1 rounded flex items-center justify-center gap-0.5">
                                <Eye size={8} /> Details
                              </button>
                              <button className="w-6 h-6 rounded border border-slate-200 flex items-center justify-center text-slate-400">
                                <Scale size={8} />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Pagination Mobile */}
                  <div className="px-3 py-2 flex items-center justify-center gap-0.5">
                    {[1,2,3].map(n => (
                      <button key={n} className={`w-6 h-6 flex items-center justify-center rounded text-[9px] font-semibold ${
                        n === 1 ? "bg-[#4a8c2a] text-white" : "border border-slate-200 text-slate-500"
                      }`}>{n}</button>
                    ))}
                    <span className="text-[9px] text-slate-400 px-0.5">...</span>
                    <button className="w-6 h-6 flex items-center justify-center rounded border border-slate-200 text-[9px] text-slate-500">8</button>
                  </div>
                </div>

                {/* Mobile Filter Modal Overlay */}
                {showMobileFilter && (
                  <div className="absolute inset-0 z-30 flex items-end">
                    <div className="absolute inset-0 bg-black/40" onClick={() => setShowMobileFilter(false)} />
                    <div className="relative w-full bg-white rounded-t-2xl shadow-2xl max-h-[80%] flex flex-col">
                      <div className="bg-[#4a8c2a] text-white px-4 py-3 flex items-center justify-between rounded-t-2xl">
                        <div className="flex items-center gap-1.5">
                          <SlidersHorizontal size={14} />
                          <span className="text-xs font-semibold">Erweiterte Filter</span>
                        </div>
                        <button onClick={() => setShowMobileFilter(false)} className="w-6 h-6 flex items-center justify-center rounded-full bg-white/20">
                          <X size={12} />
                        </button>
                      </div>
                      <div className="flex-grow overflow-y-auto">
                        {MODAL_FILTERS.slice(0, 5).map((filter, idx) => (
                          <div key={idx} className="border-b border-slate-100">
                            <button className="w-full flex items-center justify-between px-3 py-2.5 text-left">
                              <span className="text-[10px] font-semibold text-slate-700">{filter.name}</span>
                              <ChevronDown size={10} className="text-slate-400" />
                            </button>
                            {idx === 0 && (
                              <div className="px-3 pb-2 space-y-1">
                                {filter.options.slice(0, 3).map((opt, oi) => (
                                  <label key={oi} className="flex items-center gap-1.5 cursor-pointer">
                                    <input type="checkbox" className="w-3 h-3 rounded accent-[#4a8c2a]" />
                                    <span className="text-[9px] text-slate-600">{opt}</span>
                                  </label>
                                ))}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                      <div className="p-3 border-t border-slate-200 flex gap-2">
                        <button className="flex-1 text-[9px] font-medium text-slate-500 border border-slate-200 py-1.5 rounded">
                          Zurücksetzen
                        </button>
                        <button onClick={() => setShowMobileFilter(false)} className="flex-1 text-[9px] font-semibold text-white bg-[#4a8c2a] py-1.5 rounded">
                          Filter anwenden
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Mobile Feature Notes */}
            <div className="mt-6 space-y-2">
              <SectionNote
                icon={<Smartphone size={10} />}
                text="Mobile: Subcats 2-spaltig, Grundfilter kompakt (Toggle + Filter-Button + Sort), Produkte 2-spaltig mit Details + Vergleich. Filter als Bottom-Sheet Modal."
                variant="info"
              />
              <SectionNote
                icon={<AlertTriangle size={10} />}
                text="Mobile: Kurzbeschreibung ausgeblendet, nur H1 + Bild + Artikelanzahl. SEO-Text unter Produkten nur auf Seite 1."
                variant="warning"
              />
            </div>
          </div>
        )}

        {/* ══════════════════════════════════════
           IMPLEMENTATION NOTES
           ══════════════════════════════════════ */}
        <div className="max-w-5xl mx-auto mt-12">
          <h3 className="text-lg font-bold text-slate-800 mb-4" style={{ fontFamily: "var(--font-display)" }}>
            Implementierungs-Übersicht
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Template Files */}
            <div className="bg-white rounded-xl border border-slate-200 p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center">
                  <FileCode size={14} className="text-blue-600" />
                </div>
                <h4 className="text-sm font-bold text-slate-800">Template-Dateien</h4>
              </div>
              <ul className="space-y-1.5 text-[10px] text-slate-600">
                {[
                  { done: false, text: "product_listing.html – Haupttemplate (neu)" },
                  { done: false, text: "categorie_listing.html – Kategorie-Übersicht (neu)" },
                  { done: false, text: "sub_categories_listing.html – Subcats 6-spaltig" },
                  { done: false, text: "listing_filter.html – Filter-Modal + Grundfilter" },
                  { done: true, text: "pagination.html – Pagination (fertig)" },
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <Check size={10} className={`${item.done ? "text-green-500" : "text-slate-300"} mt-0.5 flex-shrink-0`} />
                    <span>{item.text}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* CSS Files */}
            <div className="bg-white rounded-xl border border-slate-200 p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 bg-purple-50 rounded-lg flex items-center justify-center">
                  <Layers size={14} className="text-purple-600" />
                </div>
                <h4 className="text-sm font-bold text-slate-800">CSS-Dateien</h4>
              </div>
              <ul className="space-y-1.5 text-[10px] text-slate-600">
                {[
                  "mrh-custom.css – Subcats 6-spaltig, Listing-Grid",
                  "pagination_layout.css – Pagination (fertig)",
                  "product_listing.css – Kachel + Liste + Buttons",
                  "filter_modal.css – Modal-Styles + Grundfilter",
                  "product_compare.css – Vergleich-Button (aus Repo)",
                ].map((text, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="w-2 h-2 bg-purple-400 rounded-full mt-1 flex-shrink-0" />
                    <span><strong>{text.split(" – ")[0]}</strong> – {text.split(" – ")[1]}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* JS + Schema */}
            <div className="bg-white rounded-xl border border-slate-200 p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 bg-green-50 rounded-lg flex items-center justify-center">
                  <Search size={14} className="text-green-600" />
                </div>
                <h4 className="text-sm font-bold text-slate-800">JS + SEO Schema</h4>
              </div>
              <ul className="space-y-1.5 text-[10px] text-slate-600">
                {[
                  "pagination.js – Scroll, KeyNav, Prefetch (fertig)",
                  "product_compare.js.php – Vergleich (aus Repo)",
                  "filter_modal.js – Modal öffnen/schließen",
                  "BreadcrumbList Schema",
                  "ItemList + Product + Offer Schema",
                  "FAQPage Schema",
                  "rel=prev/next Pagination",
                ].map((text, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="w-2 h-2 bg-green-400 rounded-full mt-1 flex-shrink-0" />
                    <span>{text}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

      </motion.div>
    </section>
  );
}
