import { useState } from "react";
import { motion } from "framer-motion";
import {
  Phone, Search, ShoppingCart, Menu, Home as HomeIcon,
  Heart, ChevronRight, ChevronDown, X, Leaf, Eye, Smartphone, Zap, ArrowRight,
  Cannabis, Sprout, Store, Lamp, Tag, BookOpen, UserRound, UserPlus, LogIn,
  Megaphone, Image, Truck
} from "lucide-react";
import { MobileProductCard, PRODUCT_IMG_1, PRODUCT_IMG_2, MRH_LOGO } from "./shared";

/* ------------------------------------------------------------------ */
/*  Wireframe: Mobile Navigation – v1.8.0 Redesign                    */
/*  Icons pro Kategorie, Suchleiste, Promo-Bereiche, Konto-Bereich    */
/* ------------------------------------------------------------------ */

const MENU_ITEMS = [
  { name: "Samen Shop", icon: <Leaf size={13} />, hasSubmenu: true },
  { name: "Cannabispflanzen", icon: <Cannabis size={13} />, hasSubmenu: true },
  { name: "Growshop", icon: <Sprout size={13} />, hasSubmenu: true },
  { name: "Headshop", icon: <Store size={13} />, hasSubmenu: true },
  { name: "Angebote", icon: <Tag size={13} />, hasSubmenu: false },
  { name: "Seedfinder", icon: <Eye size={13} />, hasSubmenu: false },
  { name: "Cannabis Blog", icon: <BookOpen size={13} />, hasSubmenu: false },
];

export default function MobileWireframe() {
  const [activeView, setActiveView] = useState<"desktop" | "mobile">("desktop");

  return (
    <section id="mobile-wireframe" className="bg-slate-50 py-20">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-white rounded-full px-4 py-1.5 mb-4 border border-slate-200">
              <Smartphone size={14} className="text-slate-500" />
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider"
                style={{ fontFamily: "var(--font-mono)" }}>Mobile Ansicht (375px)</span>
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900" style={{ fontFamily: "var(--font-display)" }}>
              Mobile Navigation
            </h2>
            <p className="text-slate-500 mt-2 max-w-lg mx-auto">
              Offcanvas-Menu mit Kategorie-Icons, Promo-Bereichen, Suchleiste und Konto-Bereich.
            </p>
          </div>

          <div className="flex justify-center mb-10">
            <div className="bg-white rounded-full p-1 border border-slate-200 flex gap-1">
              <button onClick={() => setActiveView("desktop")}
                className={`px-4 py-2 rounded-full text-xs font-semibold transition-colors ${activeView === "desktop" ? "bg-[#4a8c2a] text-white" : "text-slate-500 hover:text-slate-700"}`}>
                <Smartphone size={14} className="inline mr-1.5" />Shop-Ansicht
              </button>
              <button onClick={() => setActiveView("mobile")}
                className={`px-4 py-2 rounded-full text-xs font-semibold transition-colors ${activeView === "mobile" ? "bg-[#4a8c2a] text-white" : "text-slate-500 hover:text-slate-700"}`}>
                <Menu size={14} className="inline mr-1.5" />Offcanvas-Menu
              </button>
            </div>
          </div>

          <div className="flex flex-col lg:flex-row items-center justify-center gap-12">
            {/* Phone 1: Shop View */}
            <motion.div animate={{ opacity: activeView === "desktop" ? 1 : 0.4, scale: activeView === "desktop" ? 1 : 0.95 }} transition={{ duration: 0.3 }} className="relative">
              <div className="w-[320px] bg-black rounded-[3rem] p-3 shadow-2xl shadow-slate-400/30">
                <div className="absolute top-3 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-b-2xl z-20" />
                <div className="bg-white rounded-[2.4rem] overflow-hidden relative">
                  <div className="bg-slate-800 text-white text-[8px] px-5 pt-4 pb-1 flex justify-between">
                    <span>9:41</span>
                    <span>WiFi</span>
                  </div>
                  <div className="bg-slate-800 text-white text-[8px] px-4 py-1.5 text-center">
                    Kostenfrei ab: AT 40EUR, DE 85EUR, EU 150EUR
                  </div>
                  <div className="px-3 py-2.5 flex items-center justify-between border-b border-slate-100">
                    <button className="text-slate-600"><Menu size={18} /></button>
                    <img src={MRH_LOGO} alt="Mr. Hanf" className="h-8 w-auto object-contain" />
                    <div className="flex items-center gap-2">
                      <Search size={16} className="text-slate-500" />
                      <div className="relative">
                        <ShoppingCart size={16} className="text-slate-500" />
                        <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[6px] font-bold w-3 h-3 rounded-full flex items-center justify-center">2</span>
                      </div>
                    </div>
                  </div>
                  <div className="bg-[#f0fdf4] px-3 py-1.5">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-[#d1fae5] rounded-full h-1.5 overflow-hidden">
                        <div className="bg-[#4a8c2a] h-full rounded-full" style={{ width: "35%" }} />
                      </div>
                      <span className="text-[8px] text-[#3a7020] font-semibold whitespace-nowrap">
                        Noch <strong>85,00 EUR</strong> bis kostenloser Versand!
                      </span>
                    </div>
                  </div>
                  <div className="p-3 grid grid-cols-2 gap-2">
                    <MobileProductCard name="Amnesia Haze" brand="Royal Queen Seeds" thc="22%" type="Sativa 70%" rating={4.5} reviews={4} price="9,99 EUR" badge={{ text: "Top", color: "bg-[#4a8c2a]" }} img={PRODUCT_IMG_1} />
                    <MobileProductCard name="00 Kush FAST" brand="00 Seeds Bank" thc="22%" type="Indica 90%" rating={3.5} reviews={8} price="14,99 EUR" oldPrice="17,50 EUR" badge={{ text: "-15%", color: "bg-red-500" }} img={PRODUCT_IMG_2} />
                  </div>
                  <div className="border-t border-slate-200 bg-white px-2 py-2 flex items-center justify-around">
                    {[
                      { icon: <HomeIcon size={16} />, label: "Home", active: true },
                      { icon: <Search size={16} />, label: "Suche", active: false },
                      { icon: <Eye size={16} />, label: "Seedfinder", active: false },
                      { icon: <Heart size={16} />, label: "Merkliste", active: false },
                      { icon: <ShoppingCart size={16} />, label: "Warenkorb", active: false },
                    ].map((item, i) => (
                      <button key={i} className={`flex flex-col items-center gap-0.5 ${item.active ? "text-[#4a8c2a]" : "text-slate-400"}`}>
                        {item.icon}
                        <span className="text-[7px] font-medium">{item.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <div className="text-center mt-4">
                <span className="text-xs font-semibold text-slate-500" style={{ fontFamily: "var(--font-mono)" }}>Shop + Bottom Bar</span>
              </div>
            </motion.div>

            {/* Phone 2: Offcanvas Menu – v1.8.0 Redesign */}
            <motion.div animate={{ opacity: activeView === "mobile" ? 1 : 0.4, scale: activeView === "mobile" ? 1 : 0.95 }} transition={{ duration: 0.3 }} className="relative">
              <div className="w-[320px] bg-black rounded-[3rem] p-3 shadow-2xl shadow-slate-400/30">
                <div className="absolute top-3 left-1/2 -translate-x-1/2 w-28 h-6 bg-black rounded-b-2xl z-20" />
                <div className="bg-white rounded-[2.4rem] overflow-hidden relative">
                  <div className="bg-white text-slate-800 text-[8px] px-5 pt-4 pb-1 flex justify-between">
                    <span>9:41</span>
                    <span>WiFi</span>
                  </div>
                  <div className="relative">
                    {/* Dark overlay rechts */}
                    <div className="absolute right-0 top-0 w-14 h-full bg-black/40 z-10" />

                    {/* Offcanvas Panel */}
                    <div className="w-[calc(100%-3.5rem)]" style={{ background: "#fafcfa" }}>

                      {/* Header: Grüner Gradient */}
                      <div className="px-4 py-3 flex items-center justify-between"
                        style={{ background: "linear-gradient(135deg, #2d7a3a 0%, #1a5c28 100%)" }}>
                        <span className="text-sm font-bold text-white flex items-center gap-1.5" style={{ fontFamily: "var(--font-display)" }}>
                          <Cannabis size={14} className="opacity-90" /> Mr. Hanf
                        </span>
                        <div className="bg-white/10 rounded-md p-1">
                          <X size={14} className="text-white" />
                        </div>
                      </div>

                      {/* Suchleiste */}
                      <div className="px-3 py-2.5" style={{ background: "#f0f5f0", borderBottom: "1px solid #e2e8e2" }}>
                        <div className="flex items-center rounded-md overflow-hidden" style={{ border: "1px solid #d0dcd0" }}>
                          <input type="text" placeholder="Suchen..." className="flex-1 px-3 py-1.5 text-[11px] bg-white outline-none" readOnly />
                          <button className="bg-[#2d7a3a] text-white px-2.5 py-1.5"><Search size={11} /></button>
                        </div>
                      </div>

                      {/* Promo-Bereich OBEN (konfigurierbar via Dashboard) */}
                      <div className="px-3 py-2" style={{ borderBottom: "1px solid #eef2ee" }}>
                        <div className="rounded-lg overflow-hidden" style={{ background: "linear-gradient(135deg, #f0fdf4 0%, #e8f5e9 100%)", border: "1px solid #c8e6c9" }}>
                          <div className="px-3 py-2 flex items-center gap-2">
                            <div className="w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0" style={{ background: "#2d7a3a" }}>
                              <Megaphone size={11} className="text-white" />
                            </div>
                            <div>
                              <p className="text-[10px] font-bold text-[#2d7a3a]">2+1 GRATIS Aktion</p>
                              <p className="text-[8px] text-[#3a7020]">Auf alle Royal Queen Seeds</p>
                            </div>
                            <ArrowRight size={12} className="text-[#4a8c2a] ml-auto flex-shrink-0" />
                          </div>
                        </div>
                      </div>

                      {/* Navigation mit Icons */}
                      <div className="py-1">
                        {MENU_ITEMS.map((item, i) => (
                          <div key={i} className="flex items-center px-3 py-2 cursor-pointer transition-colors hover:bg-[#edf7ee]"
                            style={{ borderBottom: "1px solid #eef2ee" }}>
                            <div className="w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0 mr-2.5"
                              style={{ background: "rgba(45, 122, 58, 0.08)", color: "#2d7a3a" }}>
                              {item.icon}
                            </div>
                            <span className="text-[12px] text-slate-700 font-medium flex-1">{item.name}</span>
                            {item.hasSubmenu && <ChevronDown size={13} className="text-slate-400" />}
                          </div>
                        ))}
                      </div>

                      {/* Konto-Bereich */}
                      <div className="mx-3 my-2 p-3 rounded-lg" style={{ background: "#fff", border: "1px solid #e2e8e2" }}>
                        <p className="text-[10px] text-slate-500 font-semibold mb-2 pb-1.5 flex items-center gap-1"
                          style={{ borderBottom: "1px solid #eef2ee" }}>
                          <UserRound size={10} className="text-[#2d7a3a]" /> Mein Konto
                        </p>
                        <div className="flex gap-2">
                          <button className="flex-1 bg-[#2d7a3a] text-white text-[10px] font-semibold py-1.5 rounded-md flex items-center justify-center gap-1">
                            <LogIn size={10} /> Anmelden
                          </button>
                          <button className="flex-1 text-[#2d7a3a] text-[10px] font-semibold py-1.5 rounded-md flex items-center justify-center gap-1"
                            style={{ background: "#f0f5f0", border: "1px solid #d0dcd0" }}>
                            <UserPlus size={10} /> Registrieren
                          </button>
                        </div>
                      </div>

                      {/* Promo-Bereich UNTEN (konfigurierbar via Dashboard) */}
                      <div className="px-3 py-2" style={{ borderTop: "1px solid #eef2ee" }}>
                        <div className="rounded-lg overflow-hidden" style={{ background: "#fff3e0", border: "1px solid #ffe0b2" }}>
                          <div className="px-3 py-2 flex items-center gap-2">
                            <div className="w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0" style={{ background: "#e65100" }}>
                              <Image size={11} className="text-white" />
                            </div>
                            <div>
                              <p className="text-[10px] font-bold text-[#e65100]">Banner-Platzhalter</p>
                              <p className="text-[8px] text-[#bf360c]">Konfigurierbar im Dashboard</p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Footer-Info */}
                      <div className="mx-3 mb-2 px-3 py-2 rounded-md" style={{ background: "#f0f5f0" }}>
                        <p className="text-[8px] text-slate-500 flex items-center gap-1">
                          <Phone size={8} className="text-[#2d7a3a]" /> +43 512 312 411
                        </p>
                        <p className="text-[8px] text-slate-500 mt-0.5 flex items-center gap-1">
                          <Truck size={8} className="text-[#2d7a3a]" /> Versandland: <strong className="text-slate-600">Deutschland</strong>
                        </p>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
              <div className="text-center mt-4">
                <span className="text-xs font-semibold text-slate-500" style={{ fontFamily: "var(--font-mono)" }}>Offcanvas Navigation v1.8.0</span>
              </div>
            </motion.div>
          </div>

          {/* Feature Callouts */}
          <div className="max-w-4xl mx-auto mt-16 grid grid-cols-1 md:grid-cols-4 gap-5">
            {[
              { icon: <Leaf size={18} />, title: "Kategorie-Icons", desc: "Jede Hauptkategorie bekommt ein konfigurierbares FA-Icon im Dashboard." },
              { icon: <Megaphone size={18} />, title: "Mobile Promo", desc: "Banner/HTML-Werbung oben oder unten im Menu. Gesondert steuerbar." },
              { icon: <Smartphone size={18} />, title: "Bottom Nav Bar", desc: "Home, Suche, Seedfinder, Merkliste, Warenkorb. Fixiert am unteren Rand." },
              { icon: <Zap size={18} />, title: "Vanilla JS", desc: "Kein jQuery. Offcanvas mit Touch-Gesten, ESC-Close und Swipe-Support." }
            ].map((feature, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className="bg-white rounded-xl p-5 border border-slate-100">
                <div className="w-9 h-9 bg-[#f0fdf4] rounded-lg flex items-center justify-center text-[#4a8c2a] mb-3">
                  {feature.icon}
                </div>
                <h3 className="font-semibold text-slate-800 text-sm mb-1" style={{ fontFamily: "var(--font-display)" }}>{feature.title}</h3>
                <p className="text-xs text-slate-500 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
