import { motion } from "framer-motion";
import { Palette, Settings, CreditCard, Share2, ChevronDown, Check } from "lucide-react";

const colorFields = [
  { section: "Hauptfarben", icon: "circle-half-stroke", fields: [
    { name: "mrh-primary", label: "Primärfarbe", default: "rgb(74,140,42)" },
    { name: "mrh-secondary", label: "Sekundärfarbe", default: "rgb(30,30,30)" },
  ]},
  { section: "Menü-Leiste (NEU)", icon: "bars", badge: true, fields: [
    { name: "mrh-menu-bg", label: "Menü Hintergrund", default: "rgb(22,163,74)" },
    { name: "mrh-menu-text", label: "Menü Textfarbe", default: "rgb(255,255,255)" },
    { name: "mrh-menu-hover-bg", label: "Menü Hover", default: "rgba(255,255,255,0.15)" },
    { name: "mrh-menu-active-bg", label: "Menü Aktiv", default: "rgba(255,255,255,0.25)" },
  ]},
  { section: "Topbar (NEU)", icon: "grip-lines", badge: true, fields: [
    { name: "mrh-topbar-bg", label: "Topbar Hintergrund", default: "rgb(30,41,59)" },
    { name: "mrh-topbar-text", label: "Topbar Textfarbe", default: "rgb(255,255,255)" },
  ]},
  { section: "Hintergrundfarben", icon: "fill-drip", fields: [
    { name: "mrh-bg-color", label: "Hintergrundfarbe 1", default: "rgb(255,255,255)" },
    { name: "mrh-bg-color-2", label: "Hintergrundfarbe 2", default: "rgb(240,253,244)" },
    { name: "mrh-bg-productbox", label: "Produktboxen", default: "rgb(255,255,255)" },
    { name: "mrh-bg-footer", label: "Footer", default: "rgb(15,23,42)" },
  ]},
  { section: "Schriftfarben", icon: "font", fields: [
    { name: "mrh-text-standard", label: "Standard", default: "rgb(15,23,42)" },
    { name: "mrh-text-headings", label: "Überschriften", default: "rgb(15,23,42)" },
    { name: "mrh-text-button", label: "Buttons & Badges", default: "rgb(255,255,255)" },
    { name: "mrh-text-footer", label: "Footer Text", default: "rgb(148,163,184)" },
    { name: "mrh-text-footer-headings", label: "Footer Überschriften", default: "rgb(255,255,255)" },
  ]},
  { section: "Sticky Header (NEU)", icon: "thumbtack", badge: true, fields: [
    { name: "mrh-sticky-bg", label: "Sticky Hintergrund", default: "rgb(255,255,255)" },
    { name: "mrh-sticky-text", label: "Sticky Textfarbe", default: "rgb(51,65,85)" },
  ]},
];

function rgbToHex(rgb: string): string {
  const match = rgb.match(/\d+/g);
  if (!match || match.length < 3) return "#4a8c2a";
  return "#" + match.slice(0, 3).map(n => parseInt(n).toString(16).padStart(2, "0")).join("");
}

const configSections = [
  { icon: <Settings size={16} />, title: "Weitere Konfiguration", items: [
    "SSL-Zertifikat (https) aktiv?",
    "TrustedShops Siegel im Header?",
    "Menü horizontal oder vertikal?",
    "Infinite Scroll?",
    "Barrierefrei-Tool?",
  ]},
  { icon: <CreditCard size={16} />, title: "Zahlungs- und Versandlogos", items: [
    "Vorkasse, PayPal, Kreditkarten, Apple Pay, Google Pay",
    "Amazon, Klarna, Lastschrift, Rechnung",
    "Hermes, DHL, DPD, UPS, GLS, FedEx",
  ]},
  { icon: <Share2 size={16} />, title: "Social Media Links", items: [
    "Facebook, X (Twitter), Instagram, TikTok",
    "YouTube, Pinterest, LinkedIn",
  ]},
];

export default function ColorConfigurator() {
  return (
    <section id="color-configurator" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 bg-white rounded-full px-4 py-1.5 mb-4 border border-slate-200">
              <Palette size={14} className="text-[#4a8c2a]" />
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider"
                style={{ fontFamily: "var(--font-mono)" }}>Admin-Konfigurator</span>
            </div>
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900" style={{ fontFamily: "var(--font-display)" }}>
              Farb-Konfigurator
            </h2>
            <p className="text-slate-500 mt-2 max-w-xl mx-auto">
              Portiert vom RevPlus-Template und erweitert um Menü-, Topbar- und Sticky-Header-Farben.
              Nur für eingeloggte Admins sichtbar.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            {/* Hauptkarte: Farben */}
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-lg mb-6">
              <div className="bg-slate-800 text-white px-6 py-4 flex items-center gap-3">
                <Palette size={18} />
                <span className="font-bold text-sm" style={{ fontFamily: "var(--font-display)" }}>
                  Farben individualisieren
                </span>
                <span className="ml-auto text-[10px] bg-white/20 px-2 py-0.5 rounded-full">
                  21 Farbfelder
                </span>
              </div>

              <div className="p-6 space-y-6">
                {colorFields.map((group, gi) => (
                  <div key={gi}>
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                        {group.section}
                      </span>
                      {group.badge && (
                        <span className="bg-emerald-100 text-emerald-700 text-[9px] font-bold px-2 py-0.5 rounded-full">
                          NEU
                        </span>
                      )}
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                      {group.fields.map((field, fi) => (
                        <div key={fi} className="group">
                          <div className="flex items-center gap-2 mb-1.5">
                            <div
                              className="w-6 h-6 rounded-md border border-slate-200 shadow-sm flex-shrink-0"
                              style={{ background: field.default }}
                            />
                            <span className="text-[11px] font-medium text-slate-600 truncate">
                              {field.label}
                            </span>
                          </div>
                          <div className="bg-slate-50 border border-slate-200 rounded-md px-2.5 py-1.5 text-[10px] text-slate-500 font-mono truncate">
                            {field.default}
                          </div>
                          <div className="text-[9px] text-slate-400 mt-0.5 font-mono">
                            --{field.name}
                          </div>
                        </div>
                      ))}
                    </div>
                    {gi < colorFields.length - 1 && <hr className="mt-4 border-slate-100" />}
                  </div>
                ))}
              </div>

              <div className="px-6 pb-6">
                <button className="w-full bg-[#4a8c2a] text-white text-sm font-semibold py-3 rounded-xl hover:bg-[#3a7020] transition-colors flex items-center justify-center gap-2">
                  <Check size={16} /> Farben speichern
                </button>
              </div>
            </div>

            {/* Weitere Sektionen */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {configSections.map((sec, i) => (
                <div key={i} className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                  <div className="px-4 py-3 border-b border-slate-100 flex items-center gap-2">
                    <span className="text-slate-500">{sec.icon}</span>
                    <span className="text-xs font-bold text-slate-700">{sec.title}</span>
                    <ChevronDown size={12} className="ml-auto text-slate-400" />
                  </div>
                  <div className="px-4 py-3 space-y-1.5">
                    {sec.items.map((item, j) => (
                      <p key={j} className="text-[11px] text-slate-500 flex items-start gap-1.5">
                        <span className="w-1 h-1 rounded-full bg-slate-300 mt-1.5 flex-shrink-0" />
                        {item}
                      </p>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Technische Info */}
            <div className="mt-6 bg-slate-50 rounded-xl border border-slate-200 p-5">
              <h4 className="text-sm font-bold text-slate-700 mb-3" style={{ fontFamily: "var(--font-display)" }}>
                Technische Architektur
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[11px]">
                <div>
                  <p className="font-semibold text-slate-600 mb-1">Dateien:</p>
                  <ul className="space-y-1 text-slate-500">
                    <li className="font-mono bg-white px-2 py-1 rounded border border-slate-100">
                      admin/includes/mrh_configurator.php
                    </li>
                    <li className="font-mono bg-white px-2 py-1 rounded border border-slate-100">
                      smarty/mrh_color_vars.php
                    </li>
                    <li className="font-mono bg-white px-2 py-1 rounded border border-slate-100">
                      module/includes/mrh_configurator_panel.html
                    </li>
                    <li className="font-mono bg-white px-2 py-1 rounded border border-slate-100">
                      config/colors.json (Speicherung)
                    </li>
                  </ul>
                </div>
                <div>
                  <p className="font-semibold text-slate-600 mb-1">Ablauf:</p>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="bg-[#4a8c2a] text-white text-[8px] font-bold w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0">1</span>
                      <span className="text-slate-500">Admin ändert Farben im Konfigurator-Panel</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="bg-[#4a8c2a] text-white text-[8px] font-bold w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0">2</span>
                      <span className="text-slate-500">PHP speichert als config/colors.json</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="bg-[#4a8c2a] text-white text-[8px] font-bold w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0">3</span>
                      <span className="text-slate-500">mrh_color_vars.php gibt CSS Custom Properties aus</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="bg-[#4a8c2a] text-white text-[8px] font-bold w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0">4</span>
                      <span className="text-slate-500">stylesheet.css nutzt var(--mrh-*) mit Fallbacks</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Z-Index Info */}
            <div className="mt-4 bg-amber-50 rounded-xl border border-amber-200 p-5">
              <h4 className="text-sm font-bold text-amber-800 mb-3 flex items-center gap-2">
                <span className="text-amber-500">⚡</span> Z-Index Architektur (wie Original)
              </h4>
              <div className="overflow-x-auto">
                <table className="w-full text-[11px]">
                  <thead>
                    <tr className="border-b border-amber-200">
                      <th className="text-left py-2 pr-4 font-semibold text-amber-700">Element</th>
                      <th className="text-left py-2 pr-4 font-semibold text-amber-700">CSS Selektor</th>
                      <th className="text-right py-2 font-semibold text-amber-700">z-index</th>
                    </tr>
                  </thead>
                  <tbody className="text-amber-900">
                    <tr className="border-b border-amber-100">
                      <td className="py-1.5 pr-4">Admin-Bar</td>
                      <td className="py-1.5 pr-4 font-mono text-amber-600">#admin</td>
                      <td className="py-1.5 text-right font-bold">100000</td>
                    </tr>
                    <tr className="border-b border-amber-100">
                      <td className="py-1.5 pr-4">Konfigurator-Panel</td>
                      <td className="py-1.5 pr-4 font-mono text-amber-600">#mrh-configurator</td>
                      <td className="py-1.5 text-right font-bold">unter Admin</td>
                    </tr>
                    <tr className="border-b border-amber-100">
                      <td className="py-1.5 pr-4">Sticky Header</td>
                      <td className="py-1.5 pr-4 font-mono text-amber-600">#mrh-sticky-header</td>
                      <td className="py-1.5 text-right font-bold">1020</td>
                    </tr>
                    <tr className="border-b border-amber-100">
                      <td className="py-1.5 pr-4">Mega-Menü Dropdown</td>
                      <td className="py-1.5 pr-4 font-mono text-amber-600">.mrh-mega-dropdown</td>
                      <td className="py-1.5 text-right font-bold">1000</td>
                    </tr>
                    <tr className="border-b border-amber-100">
                      <td className="py-1.5 pr-4">Bottom Nav (Mobile)</td>
                      <td className="py-1.5 pr-4 font-mono text-amber-600">#mrh-bottom-nav</td>
                      <td className="py-1.5 text-right font-bold">1040</td>
                    </tr>
                    <tr className="border-b border-amber-100">
                      <td className="py-1.5 pr-4">Header</td>
                      <td className="py-1.5 pr-4 font-mono text-amber-600">#mrh-header</td>
                      <td className="py-1.5 text-right font-bold">100</td>
                    </tr>
                    <tr>
                      <td className="py-1.5 pr-4">Hauptnavigation</td>
                      <td className="py-1.5 pr-4 font-mono text-amber-600">#mrh-mainmenu</td>
                      <td className="py-1.5 text-right font-bold">100</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <p className="text-[10px] text-amber-600 mt-3">
                Header und Menü: z-index 100 (relativ positioniert, nicht fixed). Mega-Menü-Dropdown: z-index 1000 (absolute, innerhalb des Menü-Kontexts).
                Sticky Header: z-index 1020 (fixed, BS5-Standard). Admin-Bar: z-index 100000 (immer ganz oben).
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
