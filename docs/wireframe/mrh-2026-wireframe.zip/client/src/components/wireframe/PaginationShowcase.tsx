/**
 * MRH 2026 Wireframe – Pagination Showcase
 * Interaktive Demo der neuen Pagination-Komponente
 * Zeigt Desktop + Mobile Varianten, alle States, Code-Vorschau
 */
import { useState } from "react";
import { motion } from "framer-motion";
import { fadeUp } from "./shared";

/* ── Pagination-Konfig ── */
const TOTAL_PAGES = 274;
const WINDOW_SIZE = 5;

/* ── CSS Custom Properties für die Demo ── */
const pgVars: React.CSSProperties & Record<string, string> = {
  "--mrh-pg-font": "'Inter', sans-serif",
  "--mrh-pg-font-size": "0.8125rem",
  "--mrh-pg-font-weight": "500",
  "--mrh-pg-radius": "0.375rem",
  "--mrh-pg-gap": "0.25rem",
  "--mrh-pg-size": "2.25rem",
  "--mrh-pg-size-sm": "2rem",
  "--mrh-pg-transition": "150ms ease",
  "--mrh-pg-bg": "transparent",
  "--mrh-pg-text": "#374151",
  "--mrh-pg-border": "#d1d5db",
  "--mrh-pg-hover-bg": "#f0fdf4",
  "--mrh-pg-hover-text": "#166534",
  "--mrh-pg-hover-border": "#86efac",
  "--mrh-pg-active-bg": "#16a34a",
  "--mrh-pg-active-text": "#ffffff",
  "--mrh-pg-active-border": "#16a34a",
  "--mrh-pg-disabled-bg": "transparent",
  "--mrh-pg-disabled-text": "#9ca3af",
  "--mrh-pg-disabled-border": "#e5e7eb",
  "--mrh-pg-count-text": "#6b7280",
  "--mrh-pg-focus-ring": "rgba(22, 163, 74, 0.35)",
} as any;

/* ── SVG Chevrons ── */
const ChevronLeft = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
    <path d="M10 12L6 8l4-4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);
const ChevronRight = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
    <path d="M6 4l4 4-4 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

/* ── Pagination-Logik ── */
function getPageWindow(current: number, total: number, windowSize: number) {
  const curWindow = Math.ceil(current / windowSize);
  const maxWindow = Math.ceil(total / windowSize);
  const start = 1 + (curWindow - 1) * windowSize;
  const end = Math.min(curWindow * windowSize, total);
  const pages: number[] = [];
  for (let i = start; i <= end; i++) pages.push(i);
  return { pages, hasPrevWindow: curWindow > 1, hasNextWindow: curWindow < maxWindow, curWindow, maxWindow };
}

/* ── Pagination-Komponente (React-Demo) ── */
function PaginationDemo({ current, total, perPage, onPageChange, compact = false }: {
  current: number; total: number; perPage: number; onPageChange: (p: number) => void; compact?: boolean;
}) {
  const totalPages = Math.ceil(total / perPage);
  const { pages, hasPrevWindow, hasNextWindow, curWindow } = getPageWindow(current, totalPages, WINDOW_SIZE);
  const from = (current - 1) * perPage + 1;
  const to = Math.min(current * perPage, total);

  const linkBase = "inline-flex items-center justify-center text-[length:var(--mrh-pg-font-size)] font-[var(--mrh-pg-font-weight)] no-underline select-none transition-all duration-150 rounded-[var(--mrh-pg-radius)] border";
  const sizeClass = compact
    ? "min-w-[var(--mrh-pg-size-sm)] h-[var(--mrh-pg-size-sm)] px-2"
    : "min-w-[var(--mrh-pg-size)] h-[var(--mrh-pg-size)] px-2";

  return (
    <div className="mrh-pagination" style={pgVars}>
      <div className={`flex ${compact ? 'flex-col items-center gap-2' : 'flex-row justify-between items-center'} gap-2`}>
        {/* Counter */}
        <div className="text-[length:var(--mrh-pg-font-size)] whitespace-nowrap" style={{ color: "var(--mrh-pg-count-text)" }}>
          Zeige {from} bis {to} (von insgesamt {total.toLocaleString("de-DE")} Artikeln)
        </div>

        {/* Nav */}
        <nav aria-label="Seiten">
          <ul className="flex items-center gap-[var(--mrh-pg-gap)] list-none m-0 p-0">
            {/* Prev */}
            <li>
              {current > 1 ? (
                <button onClick={() => onPageChange(current - 1)}
                  className={`${linkBase} ${sizeClass} cursor-pointer`}
                  style={{ color: "var(--mrh-pg-text)", background: "var(--mrh-pg-bg)", borderColor: "var(--mrh-pg-border)" }}
                  onMouseEnter={e => { e.currentTarget.style.color = "var(--mrh-pg-hover-text)"; e.currentTarget.style.background = "var(--mrh-pg-hover-bg)"; e.currentTarget.style.borderColor = "var(--mrh-pg-hover-border)"; }}
                  onMouseLeave={e => { e.currentTarget.style.color = "var(--mrh-pg-text)"; e.currentTarget.style.background = "var(--mrh-pg-bg)"; e.currentTarget.style.borderColor = "var(--mrh-pg-border)"; }}
                  aria-label="Vorherige Seite" title="Vorherige Seite">
                  <ChevronLeft />
                </button>
              ) : (
                <span className={`${linkBase} ${sizeClass} opacity-50 cursor-not-allowed`}
                  style={{ color: "var(--mrh-pg-disabled-text)", background: "var(--mrh-pg-disabled-bg)", borderColor: "var(--mrh-pg-disabled-border)" }}>
                  <ChevronLeft />
                </span>
              )}
            </li>

            {/* Prev Window */}
            {hasPrevWindow && (
              <li>
                <button onClick={() => onPageChange((curWindow - 1) * WINDOW_SIZE)}
                  className={`${linkBase} ${sizeClass} cursor-pointer border-transparent bg-transparent`}
                  style={{ color: "var(--mrh-pg-text)" }}
                  onMouseEnter={e => { e.currentTarget.style.color = "var(--mrh-pg-hover-text)"; e.currentTarget.style.background = "var(--mrh-pg-hover-bg)"; e.currentTarget.style.borderColor = "var(--mrh-pg-hover-border)"; }}
                  onMouseLeave={e => { e.currentTarget.style.color = "var(--mrh-pg-text)"; e.currentTarget.style.background = "transparent"; e.currentTarget.style.borderColor = "transparent"; }}
                  title={`Vorherige ${WINDOW_SIZE} Seiten`}>
                  &hellip;
                </button>
              </li>
            )}

            {/* Page Numbers */}
            {pages.map(p => (
              <li key={p}>
                {p === current ? (
                  <span className={`${linkBase} ${sizeClass} font-bold cursor-default pointer-events-none`}
                    style={{ color: "var(--mrh-pg-active-text)", background: "var(--mrh-pg-active-bg)", borderColor: "var(--mrh-pg-active-border)" }}
                    aria-current="page">
                    {p}
                  </span>
                ) : (
                  <button onClick={() => onPageChange(p)}
                    className={`${linkBase} ${sizeClass} cursor-pointer`}
                    style={{ color: "var(--mrh-pg-text)", background: "var(--mrh-pg-bg)", borderColor: "var(--mrh-pg-border)" }}
                    onMouseEnter={e => { e.currentTarget.style.color = "var(--mrh-pg-hover-text)"; e.currentTarget.style.background = "var(--mrh-pg-hover-bg)"; e.currentTarget.style.borderColor = "var(--mrh-pg-hover-border)"; }}
                    onMouseLeave={e => { e.currentTarget.style.color = "var(--mrh-pg-text)"; e.currentTarget.style.background = "var(--mrh-pg-bg)"; e.currentTarget.style.borderColor = "var(--mrh-pg-border)"; }}
                    title={`Seite ${p}`}>
                    {p}
                  </button>
                )}
              </li>
            ))}

            {/* Next Window */}
            {hasNextWindow && (
              <li>
                <button onClick={() => onPageChange(curWindow * WINDOW_SIZE + 1)}
                  className={`${linkBase} ${sizeClass} cursor-pointer border-transparent bg-transparent`}
                  style={{ color: "var(--mrh-pg-text)" }}
                  onMouseEnter={e => { e.currentTarget.style.color = "var(--mrh-pg-hover-text)"; e.currentTarget.style.background = "var(--mrh-pg-hover-bg)"; e.currentTarget.style.borderColor = "var(--mrh-pg-hover-border)"; }}
                  onMouseLeave={e => { e.currentTarget.style.color = "var(--mrh-pg-text)"; e.currentTarget.style.background = "transparent"; e.currentTarget.style.borderColor = "transparent"; }}
                  title={`Nächste ${WINDOW_SIZE} Seiten`}>
                  &hellip;
                </button>
              </li>
            )}

            {/* Next */}
            <li>
              {current < Math.ceil(total / perPage) ? (
                <button onClick={() => onPageChange(current + 1)}
                  className={`${linkBase} ${sizeClass} cursor-pointer`}
                  style={{ color: "var(--mrh-pg-text)", background: "var(--mrh-pg-bg)", borderColor: "var(--mrh-pg-border)" }}
                  onMouseEnter={e => { e.currentTarget.style.color = "var(--mrh-pg-hover-text)"; e.currentTarget.style.background = "var(--mrh-pg-hover-bg)"; e.currentTarget.style.borderColor = "var(--mrh-pg-hover-border)"; }}
                  onMouseLeave={e => { e.currentTarget.style.color = "var(--mrh-pg-text)"; e.currentTarget.style.background = "var(--mrh-pg-bg)"; e.currentTarget.style.borderColor = "var(--mrh-pg-border)"; }}
                  aria-label="Nächste Seite" title="Nächste Seite">
                  <ChevronRight />
                </button>
              ) : (
                <span className={`${linkBase} ${sizeClass} opacity-50 cursor-not-allowed`}
                  style={{ color: "var(--mrh-pg-disabled-text)", background: "var(--mrh-pg-disabled-bg)", borderColor: "var(--mrh-pg-disabled-border)" }}>
                  <ChevronRight />
                </span>
              )}
            </li>
          </ul>
        </nav>
      </div>
    </div>
  );
}

/* ── Haupt-Showcase ── */
export default function PaginationShowcase() {
  const [currentPage, setCurrentPage] = useState(3);
  const [activeTab, setActiveTab] = useState<"demo" | "html" | "css" | "js">("demo");
  const totalProducts = 1640;
  const perPage = 6;

  const tabs = [
    { id: "demo" as const, label: "Live-Demo" },
    { id: "html" as const, label: "Smarty HTML" },
    { id: "css" as const, label: "CSS" },
    { id: "js" as const, label: "Vanilla JS" },
  ];

  return (
    <section id="pagination-showcase" className="py-16 lg:py-24 bg-white">
      <div className="container mx-auto px-4">
        <motion.div variants={fadeUp} initial="hidden" whileInView="visible" viewport={{ once: true }}>

          {/* Header */}
          <div className="flex items-center gap-2 mb-4">
            <span className="w-8 h-0.5 bg-[#4a8c2a]" />
            <span className="text-xs font-semibold text-[#4a8c2a] uppercase tracking-[0.2em]"
              style={{ fontFamily: "var(--font-mono)" }}>Komponente</span>
          </div>
          <h2 className="text-3xl lg:text-4xl font-extrabold text-slate-900 mb-3"
            style={{ fontFamily: "var(--font-display)" }}>
            Pagination <span className="text-[#4a8c2a]">v2.0</span>
          </h2>
          <p className="text-slate-600 mb-8 max-w-2xl">
            Komplett neu designte Pagination-Komponente. Mobile First, BEM-Methodik, CSS Custom Properties,
            Vanilla JS (kein jQuery), SEO-optimiert mit rel="prev/next", aria-Labels und Keyboard-Navigation.
          </p>

          {/* Tabs */}
          <div className="flex gap-1 mb-6 bg-slate-100 rounded-lg p-1 w-fit">
            {tabs.map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                  activeTab === tab.id
                    ? "bg-white text-slate-900 shadow-sm"
                    : "text-slate-500 hover:text-slate-700"
                }`}>
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="bg-slate-50 rounded-2xl border border-slate-200 overflow-hidden">

            {/* DEMO TAB */}
            {activeTab === "demo" && (
              <div className="p-6 lg:p-8 space-y-10">

                {/* Desktop Variante */}
                <div>
                  <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-4">
                    Desktop (ab 576px) – Counter links, Navigation rechts
                  </h3>
                  <div className="bg-white rounded-xl border border-slate-200 p-4 lg:p-6">
                    <PaginationDemo current={currentPage} total={totalProducts} perPage={perPage}
                      onPageChange={setCurrentPage} />
                  </div>
                </div>

                {/* Mobile Variante */}
                <div>
                  <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-4">
                    Mobile (unter 576px) – Zentriert, gestapelt
                  </h3>
                  <div className="mx-auto" style={{ maxWidth: "375px" }}>
                    <div className="bg-white rounded-xl border border-slate-200 p-4">
                      <PaginationDemo current={currentPage} total={totalProducts} perPage={perPage}
                        onPageChange={setCurrentPage} compact />
                    </div>
                  </div>
                </div>

                {/* States */}
                <div>
                  <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-4">
                    Alle States
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Erste Seite */}
                    <div className="bg-white rounded-xl border border-slate-200 p-4">
                      <p className="text-xs text-slate-400 mb-2 font-medium">Erste Seite (Zurück deaktiviert)</p>
                      <PaginationDemo current={1} total={totalProducts} perPage={perPage}
                        onPageChange={() => {}} compact />
                    </div>
                    {/* Letzte Seite */}
                    <div className="bg-white rounded-xl border border-slate-200 p-4">
                      <p className="text-xs text-slate-400 mb-2 font-medium">Letzte Seite (Weiter deaktiviert)</p>
                      <PaginationDemo current={TOTAL_PAGES} total={totalProducts} perPage={perPage}
                        onPageChange={() => {}} compact />
                    </div>
                    {/* Mittlere Seite */}
                    <div className="bg-white rounded-xl border border-slate-200 p-4">
                      <p className="text-xs text-slate-400 mb-2 font-medium">Mittlere Seite (beide Ellipsen)</p>
                      <PaginationDemo current={138} total={totalProducts} perPage={perPage}
                        onPageChange={() => {}} compact />
                    </div>
                    {/* Wenige Seiten */}
                    <div className="bg-white rounded-xl border border-slate-200 p-4">
                      <p className="text-xs text-slate-400 mb-2 font-medium">Wenige Ergebnisse (3 Seiten)</p>
                      <PaginationDemo current={2} total={18} perPage={perPage}
                        onPageChange={() => {}} compact />
                    </div>
                  </div>
                </div>

                {/* Features */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {[
                    { icon: "fa-mobile-alt", title: "Mobile First", desc: "32px Touch-Targets auf Mobile, 36-40px auf Desktop" },
                    { icon: "fa-universal-access", title: "Accessibility", desc: "aria-current, aria-label, focus-visible, Keyboard-Nav" },
                    { icon: "fa-search", title: "SEO 2026", desc: "rel=prev/next, semantisches <nav>, saubere URLs" },
                    { icon: "fa-bolt", title: "Performance", desc: "Prefetch nächste Seite, kein jQuery, CSS Custom Props" },
                  ].map((f, i) => (
                    <div key={i} className="bg-white rounded-xl border border-slate-200 p-4">
                      <span className={`fa ${f.icon} text-[#4a8c2a] text-lg mb-2 block`} />
                      <h4 className="text-sm font-bold text-slate-900 mb-1">{f.title}</h4>
                      <p className="text-xs text-slate-500">{f.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* HTML TAB */}
            {activeTab === "html" && (
              <div className="p-6 lg:p-8">
                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-4">
                  pagination.html (Smarty Template)
                </h3>
                <pre className="bg-slate-900 text-slate-100 rounded-xl p-4 lg:p-6 overflow-x-auto text-xs leading-relaxed">
                  <code>{`{* MRH 2026 – Pagination Component v2.0 *}

{if isset($DISPLAY_LINKS) || isset($DISPLAY_COUNT)}
<div class="mrh-pagination" role="navigation"
     aria-label="Seitennavigation">
  <div class="mrh-pagination__bar">

    {if isset($DISPLAY_COUNT)}
      <div class="mrh-pagination__count">
        {$DISPLAY_COUNT}
      </div>
    {/if}

    {if isset($DISPLAY_LINKS)}
    <nav class="mrh-pagination__nav" aria-label="Seiten">
      <ul class="mrh-pagination__list">

        {* ◀ Zurück *}
        {if isset($DISPLAY_LINKS.previous_data)}
          <li class="mrh-pagination__item
              mrh-pagination__item--prev">
            <a class="mrh-pagination__link"
               href="{$DISPLAY_LINKS.previous_data.LINK}"
               rel="prev">
              <svg class="mrh-pagination__icon" ...>
                <path d="M10 12L6 8l4-4" .../>
              </svg>
            </a>
          </li>
        {else}
          <li class="... --disabled" aria-hidden="true">
            <span class="... --disabled">◀</span>
          </li>
        {/if}

        {* Seitenzahlen *}
        {foreach item="pages" from=$DISPLAY_LINKS.pages_data}
          {if $pages.CURRENT == 1}
            <li class="... --active" aria-current="page">
              <span class="... --current">
                {$pages.TEXT}
              </span>
            </li>
          {else}
            <li class="mrh-pagination__item">
              <a class="mrh-pagination__link"
                 href="{$pages.LINK}">
                {$pages.TEXT}
              </a>
            </li>
          {/if}
        {/foreach}

        {* ▶ Weiter *}
        {if isset($DISPLAY_LINKS.next_data)}
          <li class="... --next">
            <a class="mrh-pagination__link"
               href="{$DISPLAY_LINKS.next_data.LINK}"
               rel="next">▶</a>
          </li>
        {/if}

      </ul>
    </nav>
    {/if}
  </div>
</div>
{/if}`}</code>
                </pre>
                <p className="text-xs text-slate-400 mt-3">
                  Vollständige Datei: <code className="bg-slate-200 px-1.5 py-0.5 rounded text-slate-600">tpl_mrh_2026/module/pagination.html</code>
                </p>
              </div>
            )}

            {/* CSS TAB */}
            {activeTab === "css" && (
              <div className="p-6 lg:p-8">
                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-4">
                  pagination_layout.css (Custom Properties + BEM)
                </h3>
                <pre className="bg-slate-900 text-slate-100 rounded-xl p-4 lg:p-6 overflow-x-auto text-xs leading-relaxed">
                  <code>{`:root {
  --mrh-pg-radius:      0.375rem;
  --mrh-pg-size:        2.25rem;    /* Desktop */
  --mrh-pg-size-sm:     2rem;       /* Mobile  */
  --mrh-pg-transition:  150ms ease;

  /* Farben – Neutral */
  --mrh-pg-text:        #374151;
  --mrh-pg-border:      #d1d5db;

  /* Farben – Hover */
  --mrh-pg-hover-bg:    #f0fdf4;
  --mrh-pg-hover-text:  #166534;
  --mrh-pg-hover-border:#86efac;

  /* Farben – Aktiv */
  --mrh-pg-active-bg:   #16a34a;    /* Brand Grün */
  --mrh-pg-active-text: #ffffff;

  /* Farben – Deaktiviert */
  --mrh-pg-disabled-text: #9ca3af;
  --mrh-pg-disabled-border:#e5e7eb;
}

/* Mobile First: Vertikal gestapelt */
.mrh-pagination__bar {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.625rem;
}

/* Tablet+: Horizontal */
@media (min-width: 576px) {
  .mrh-pagination__bar {
    flex-direction: row;
    justify-content: space-between;
  }
}

/* Link-Basis */
.mrh-pagination__link {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: var(--mrh-pg-size-sm);
  height: var(--mrh-pg-size-sm);
  border: 1px solid var(--mrh-pg-border);
  border-radius: var(--mrh-pg-radius);
  transition: all var(--mrh-pg-transition);
}

/* Aktive Seite */
.mrh-pagination__link--current {
  background: var(--mrh-pg-active-bg);
  color: var(--mrh-pg-active-text);
  font-weight: 700;
  pointer-events: none;
}

/* Deaktiviert */
.mrh-pagination__link--disabled {
  opacity: 0.5;
  cursor: not-allowed;
  pointer-events: none;
}

/* Desktop: Größere Targets */
@media (min-width: 768px) {
  .mrh-pagination__link {
    min-width: var(--mrh-pg-size);
    height: var(--mrh-pg-size);
  }
}`}</code>
                </pre>
                <p className="text-xs text-slate-400 mt-3">
                  Vollständige Datei: <code className="bg-slate-200 px-1.5 py-0.5 rounded text-slate-600">tpl_mrh_2026/css/pagination_layout.css</code>
                </p>
              </div>
            )}

            {/* JS TAB */}
            {activeTab === "js" && (
              <div className="p-6 lg:p-8">
                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-4">
                  pagination.js (Vanilla JS – kein jQuery)
                </h3>
                <pre className="bg-slate-900 text-slate-100 rounded-xl p-4 lg:p-6 overflow-x-auto text-xs leading-relaxed">
                  <code>{`/**
 * MRH 2026 – Pagination Vanilla JS
 * Features:
 *   1. Scroll-to-Products nach Seitenwechsel
 *   2. Keyboard-Navigation (← →)
 *   3. Prefetch nächste Seite bei Hover
 */
(function () {
  'use strict';

  var CONFIG = {
    scrollTarget: '#products-listing, .mrh-product-listing',
    scrollOffset: -20,
    scrollBehavior: 'smooth',
    prefetchEnabled: true,
    keyNavEnabled: true
  };

  /* 1. Scroll-to-Products */
  function scrollToProducts() {
    var params = new URLSearchParams(location.search);
    if (!params.has('page') || params.get('page') === '1')
      return;

    var selectors = CONFIG.scrollTarget.split(',');
    var target = null;
    for (var i = 0; i < selectors.length; i++) {
      target = document.querySelector(selectors[i].trim());
      if (target) break;
    }
    if (!target) return;

    setTimeout(function () {
      var y = target.getBoundingClientRect().top
            + window.pageYOffset
            + CONFIG.scrollOffset;
      window.scrollTo({ top: Math.max(0, y),
                         behavior: CONFIG.scrollBehavior });
    }, 100);
  }

  /* 2. Keyboard-Navigation */
  function initKeyNav() {
    if (!CONFIG.keyNavEnabled) return;
    document.addEventListener('keydown', function (e) {
      var tag = document.activeElement?.tagName || '';
      if (['INPUT','TEXTAREA','SELECT'].includes(tag))
        return;

      var link = null;
      if (e.key === 'ArrowLeft')
        link = document.querySelector(
          '.mrh-pagination__item--prev a');
      else if (e.key === 'ArrowRight')
        link = document.querySelector(
          '.mrh-pagination__item--next a');

      if (link?.href) { e.preventDefault(); link.click(); }
    });
  }

  /* 3. Prefetch nächste Seite */
  function initPrefetch() {
    if (!CONFIG.prefetchEnabled) return;
    var next = document.querySelector(
      '.mrh-pagination__item--next a');
    if (!next?.href) return;

    next.addEventListener('mouseenter', function () {
      var link = document.createElement('link');
      link.rel = 'prefetch';
      link.href = next.href;
      link.as = 'document';
      document.head.appendChild(link);
    }, { once: true });
  }

  /* Init */
  if (document.readyState === 'loading')
    document.addEventListener('DOMContentLoaded', init);
  else init();

  function init() {
    scrollToProducts();
    initKeyNav();
    initPrefetch();
  }
})();`}</code>
                </pre>
                <p className="text-xs text-slate-400 mt-3">
                  Vollständige Datei: <code className="bg-slate-200 px-1.5 py-0.5 rounded text-slate-600">tpl_mrh_2026/js/pagination.js</code>
                </p>
              </div>
            )}
          </div>

          {/* Vergleichstabelle Alt vs. Neu */}
          <div className="mt-10">
            <h3 className="text-xl font-bold text-slate-900 mb-4" style={{ fontFamily: "var(--font-display)" }}>
              Alt vs. Neu – Pagination Vergleich
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-slate-100">
                    <th className="text-left p-3 font-semibold text-slate-700 border-b border-slate-200">Eigenschaft</th>
                    <th className="text-left p-3 font-semibold text-red-600 border-b border-slate-200">Alt (Bootstrap 4)</th>
                    <th className="text-left p-3 font-semibold text-[#4a8c2a] border-b border-slate-200">Neu (MRH 2026)</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    ["CSS-Methodik", "Bootstrap 4 Klassen (.pagination, .page-item)", "BEM (.mrh-pagination__link--current)"],
                    ["Custom Properties", "Keine", "20+ CSS Variables (Farben, Größen, Radien)"],
                    ["Touch-Targets", "~30px (zu klein)", "32px Mobile / 36-40px Desktop"],
                    ["Accessibility", "Minimal", "aria-current, aria-label, focus-visible, role"],
                    ["SEO", "Keine rel-Attribute", "rel='prev' / rel='next' auf Links"],
                    ["Icons", "Font Awesome (fa-chevron)", "Inline SVG (kein Icon-Font nötig)"],
                    ["JavaScript", "jQuery-abhängig", "Vanilla JS (Scroll, KeyNav, Prefetch)"],
                    ["Deaktivierte Buttons", "Nicht angezeigt", "Sichtbar aber deaktiviert (UX)"],
                    ["Responsive", "float-left/right", "Flexbox Mobile First"],
                    ["Konfigurator", "Nicht unterstützt", "CSS Variables via Farb-Konfigurator"],
                    ["Print", "Wird gedruckt", "display: none (spart Papier)"],
                    ["Prefetch", "Nein", "Nächste Seite bei Hover vorladen"],
                  ].map(([prop, old, neu], i) => (
                    <tr key={i} className={i % 2 === 0 ? "bg-white" : "bg-slate-50"}>
                      <td className="p-3 font-medium text-slate-700 border-b border-slate-100">{prop}</td>
                      <td className="p-3 text-slate-500 border-b border-slate-100">{old}</td>
                      <td className="p-3 text-slate-700 border-b border-slate-100">{neu}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </motion.div>
      </div>
    </section>
  );
}
