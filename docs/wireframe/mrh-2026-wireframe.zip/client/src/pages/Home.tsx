/**
 * MRH 2026 Wireframe - Clean Showcase
 * Assembles all wireframe sections from component files
 */
import { motion } from "framer-motion";
import { fadeUp, HERO_BG, MRH_LOGO } from "@/components/wireframe/shared";
import DesktopWireframe from "@/components/wireframe/DesktopWireframe";
import MobileWireframe from "@/components/wireframe/MobileWireframe";
import LayoutAndSeo from "@/components/wireframe/LayoutAndSeo";
import TechSpecs from "@/components/wireframe/TechSpecs";
import ColorConfigurator from "@/components/wireframe/ColorConfigurator";
import PaginationShowcase from "@/components/wireframe/PaginationShowcase";
import CategoryPageWireframe from "@/components/wireframe/CategoryPageWireframe";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#fafaf8]">

      {/* HERO SECTION */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img src={HERO_BG} alt="" className="w-full h-full object-cover opacity-40" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#fafaf8]/60 via-[#fafaf8]/30 to-[#fafaf8]" />
        </div>
        <div className="relative z-10 container mx-auto px-4 pt-16 pb-24 lg:pt-24 lg:pb-32">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            <motion.div initial="hidden" animate="visible" className="max-w-2xl flex-1">
              <motion.div variants={fadeUp} custom={0} className="flex items-center gap-2 mb-6">
                <span className="w-8 h-0.5 bg-[#4a8c2a]" />
                <span className="text-xs font-semibold text-[#4a8c2a] uppercase tracking-[0.2em]"
                  style={{ fontFamily: "var(--font-mono)" }}>Template Wireframe 2026</span>
              </motion.div>
              <motion.h1 variants={fadeUp} custom={1}
                className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 leading-[1.1] mb-6"
                style={{ fontFamily: "var(--font-display)" }}>
                MRH 2026<span className="block text-[#4a8c2a]">Template Wireframe</span>
              </motion.h1>
              <motion.p variants={fadeUp} custom={2}
                className="text-lg text-slate-600 leading-relaxed mb-8 max-w-xl">
                Interaktiver Prototyp des neuen mr-hanf.de Templates. Bootstrap 5.3, Mobile First,
                keine Sidebar, SEO 2026 und AI-Search optimiert.
              </motion.p>
              <motion.div variants={fadeUp} custom={3} className="flex flex-wrap gap-3">
                <a href="#desktop-wireframe" className="bg-[#4a8c2a] hover:bg-[#3a7020] text-white text-sm font-semibold px-6 py-3 rounded-xl transition-colors">
                  Desktop ansehen
                </a>
                <a href="#mobile-wireframe" className="bg-white hover:bg-slate-50 text-slate-700 text-sm font-semibold px-6 py-3 rounded-xl border border-slate-200 transition-colors">
                  Mobile ansehen
                </a>
                <a href="#layout-seo" className="bg-white hover:bg-slate-50 text-slate-700 text-sm font-semibold px-6 py-3 rounded-xl border border-slate-200 transition-colors">
                  SEO &amp; Layout
                </a>
                <a href="#category-page-wireframe" className="bg-[#4a8c2a] hover:bg-[#3a7020] text-white text-sm font-semibold px-6 py-3 rounded-xl transition-colors">
                  Kategorie-Seite
                </a>
                <a href="#pagination-showcase" className="bg-white hover:bg-slate-50 text-slate-700 text-sm font-semibold px-6 py-3 rounded-xl border border-slate-200 transition-colors">
                  Pagination
                </a>
                <a href="#color-configurator" className="bg-white hover:bg-slate-50 text-slate-700 text-sm font-semibold px-6 py-3 rounded-xl border border-slate-200 transition-colors">
                  Farb-Konfigurator
                </a>
              </motion.div>
            </motion.div>
            <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3, duration: 0.6 }} className="flex-shrink-0">
              <img src={MRH_LOGO} alt="Mr. Hanf Logo" className="w-48 lg:w-64 h-auto drop-shadow-xl" />
            </motion.div>
          </div>

          {/* Stats */}
          <motion.div variants={fadeUp} custom={4} initial="hidden" animate="visible"
            className="mt-16 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-2xl">
            {[
              { value: "5.3", label: "Bootstrap" },
              { value: "0", label: "jQuery Abhaengigkeiten" },
              { value: "100", label: "Mobile First Score" },
              { value: "A+", label: "SEO 2026 Rating" },
            ].map((stat, i) => (
              <div key={i} className="bg-white/70 backdrop-blur-sm rounded-xl px-4 py-3 border border-slate-200/50">
                <p className="text-2xl font-extrabold text-[#4a8c2a]" style={{ fontFamily: "var(--font-display)" }}>{stat.value}</p>
                <p className="text-xs text-slate-500 mt-0.5">{stat.label}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* DESKTOP WIREFRAME */}
      <DesktopWireframe />

      {/* MOBILE WIREFRAME */}
      <MobileWireframe />

      {/* LAYOUT & SEO */}
      <LayoutAndSeo />

      {/* TECH SPECS */}
      <TechSpecs />

      {/* CATEGORY PAGE WIREFRAME */}
      <CategoryPageWireframe />

      {/* PAGINATION SHOWCASE */}
      <PaginationShowcase />

      {/* COLOR CONFIGURATOR */}
      <ColorConfigurator />

      {/* FOOTER */}
      <footer className="bg-slate-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-slate-400 mb-2">
            MRH 2026 Template Wireframe - Entwicklungsdokumentation
          </p>
          <div className="flex items-center justify-center gap-4 text-xs text-slate-500">
            <a href="https://github.com/mrhanf15-stack/Template-MRH-2026" target="_blank" rel="noopener noreferrer"
              className="hover:text-white transition-colors">GitHub Repository</a>
            <span>|</span>
            <span>Bootstrap 5.3 | Font Awesome | PHP 8.3</span>
            <span>|</span>
            <span>modified eCommerce v2.0.7.2</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
